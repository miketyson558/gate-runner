みんなのジグソーパズル Android対応版
====================================

■ 内容
- index.html : 起動用ファイル（GitHub Pagesではこれを開きます）
- minna no jigsaw.html : 元のファイル名を残した修正版
- manifest.webmanifest : Androidホーム画面追加用の設定
- sw.js : アプリ本体のオフラインキャッシュ
- icons/ : アプリアイコン

■ Androidでの使い方
1. ZIPを解凍します。
2. GitHubの miketyson558/gate-runner リポジトリの main ブランチに、index.html / minna_no_jigsaw.html / manifest.webmanifest / sw.js / icons フォルダをアップロードします。
   ※同名ファイルがある場合は上書きしてください。
3. GitHub Pagesを有効にして、公開URLをChromeで開きます。
4. Chrome右上の「︙」→「アプリをインストール」または「ホーム画面に追加」を選びます。
5. ホーム画面に追加された「ジグソーパズル」から起動できます。

■ Android向け修正
- 画面の高さ・アドレスバー変化・縦横回転に合わせて盤面を再調整
- ピース置き場のドラッグ時にポインターをトレー側で保持し、Androidのタッチ操作を安定化
- タッチ中のブラウザ誤スクロール／選択を抑制
- Androidのホーム画面インストール設定とアイコンを追加
- アプリ本体をService Workerでキャッシュ（初回表示後の再表示に対応）

■ 注意
- これはAndroid用のインストール可能なWebアプリ（PWA）です。APKファイルではありません。
- ネット写真の取得・ランダム表示にはインターネット接続が必要です。
- 自分で追加した写真は端末内のIndexedDBに保存します。ブラウザのデータを消去すると保存写真も消える場合があります。
- GitHub Pagesの公開先がリポジトリのルートでない場合は、ファイルを公開フォルダに配置してください。
