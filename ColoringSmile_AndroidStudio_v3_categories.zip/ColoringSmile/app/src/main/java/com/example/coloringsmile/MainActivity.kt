package com.example.coloringsmile

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint as AndroidPaint
import android.graphics.Path as AndroidPath
import android.graphics.RectF
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items as lazyItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FlipToBack
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.clickable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.io.FileOutputStream
import java.io.FileInputStream
import android.app.WallpaperManager
import android.widget.Toast
import java.io.IOException
import kotlin.math.max
import kotlin.math.min

private val Pink = Color(0xFFFF6FAE)
private val PinkDark = Color(0xFFE54C91)
private val Cream = Color(0xFFFFF7FB)
private val Ink = Color(0xFF34303A)
private val Soft = Color(0xFFFFE5F0)

data class StrokeData(
    val points: List<Offset>,
    val color: Color,
    val width: Float
)

data class ColoringPage(
    val id: Int,
    val category: String,
    val title: String,
    val emoji: String,
    val template: Int,
    val variant: Int
)

private val categories = listOf(
    "どうぶつ", "のりもの", "きょうりゅう", "うちゅう", "おはな",
    "おかし", "おひめさま", "うみ", "きせつ", "ぼうけん"
)
private val categoryEmoji = listOf("🐱","🚗","🦖","🚀","🌼","🍰","👑","🐳","🌸","🗺️")
private val titleA = listOf("にこにこ", "わくわく", "ふしぎな", "ゆめみる", "たのしい", "ほしぞら", "もりの", "うみの", "おかしな", "カラフルな")
private val titleB = listOf("なかまたち", "せかい", "だいぼうけん", "ものがたり", "ひみつ", "まつり", "ドリーム", "パーティー", "ランド", "タイム")

// 10カテゴリー × 100バリエーション = 1,000作品。
// 画像ファイルを大量に同梱せず、端末上で線画を生成するのでアプリ容量を抑えています。
private val pages: List<ColoringPage> = List(1000) { index ->
    val id = index + 1
    val categoryIndex = index / 100
    val template = categoryIndex + 1
    val variant = index % 100
    ColoringPage(
        id = id,
        category = categories[categoryIndex],
        title = "${titleA[index % titleA.size]}${titleB[index % titleB.size]} #${id.toString().padStart(4, '0')}",
        emoji = categoryEmoji[categoryIndex],
        template = template,
        variant = variant
    )
}

// 12色相 × 8段階 = 96色。ぬりえ画面では横スクロールで選べます。
private val palette: List<Color> = buildList {
    val hues = listOf(0f, 30f, 60f, 90f, 120f, 150f, 180f, 210f, 240f, 270f, 300f, 330f)
    val saturations = listOf(0.95f, 0.78f, 0.62f)
    val values = listOf(1f, 0.88f, 0.72f, 0.56f, 0.40f, 0.28f, 0.18f, 0.10f)
    for (h in hues) for (s in saturations.take(1)) for (v in values) add(Color.hsv(h, s, v))
    addAll(listOf(Color.White, Color(0xFFF5F5F5), Color(0xFFBDBDBD), Color(0xFF777777), Color(0xFF424242), Color(0xFF212121)))
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ColoringSmileApp() }
    }
}

@Composable
fun ColoringSmileApp() {
    var screen by remember { mutableStateOf("home") }
    var selectedPage by remember { mutableStateOf(pages.first()) }
    var soundOn by remember { mutableStateOf(true) }
    var savedRefresh by remember { mutableStateOf(0) }
    val context = LocalContext.current

    MaterialTheme(
        colorScheme = androidx.compose.material3.lightColorScheme(
            primary = PinkDark,
            secondary = Pink,
            background = Cream,
            surface = Color.White,
            onSurface = Ink
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Cream) {
            AnimatedContent(
                targetState = screen,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "screen"
            ) { target ->
                when (target) {
                    "home" -> HomeScreen(
                        onStart = { selectedPage = pages.first(); screen = "select" },
                        onGallery = { screen = "gallery" },
                        soundOn = soundOn,
                        onSound = { soundOn = !soundOn }
                    )
                    "select" -> SelectScreen(
                        onBack = { screen = "home" },
                        onSelect = { page ->
                            selectedPage = page
                            screen = "paint"
                        }
                    )
                    "paint" -> PaintScreen(
                        page = selectedPage,
                        soundOn = soundOn,
                        onBack = { screen = "select" },
                        onSaved = { savedRefresh++ }
                    )
                    "gallery" -> GalleryScreen(
                        refreshKey = savedRefresh,
                        onBack = { screen = "home" }
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    onStart: () -> Unit,
    onGallery: () -> Unit,
    soundOn: Boolean,
    onSound: () -> Unit
) {
    val scale by animateFloatAsState(1f, label = "titleScale")
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(54.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            IconButton(onClick = onSound) {
                Icon(
                    if (soundOn) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                    contentDescription = "効果音"
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("ぬりえ", fontSize = 44.sp, fontWeight = FontWeight.ExtraBold, color = PinkDark, modifier = Modifier.scale(scale))
        Text("スマイル", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(8.dp))
        Text("かわいく、かんたん。指でぬって楽しもう！", color = Color(0xFF6C6670))
        Spacer(Modifier.height(28.dp))

        Card(
            modifier = Modifier.fillMaxWidth().aspectRatio(1.18f),
            shape = RoundedCornerShape(30.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(6.dp)
        ) {
            Box(Modifier.fillMaxSize().padding(18.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) { drawFlowerScene() }
            }
        }

        Spacer(Modifier.height(26.dp))
        Button(
            onClick = onStart,
            modifier = Modifier.fillMaxWidth().height(58.dp),
            shape = RoundedCornerShape(22.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PinkDark)
        ) {
            Icon(Icons.Default.PlayArrow, null)
            Spacer(Modifier.width(8.dp))
            Text("ぬりえをはじめる", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onGallery,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Soft, contentColor = PinkDark)
        ) {
            Icon(Icons.Default.Image, null)
            Spacer(Modifier.width(8.dp))
            Text("保存した作品を見る", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.weight(1f))
        Text("広告・懸賞なし / オフラインで遊べます", fontSize = 12.sp, color = Color(0xFF8A838C))
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun SelectScreen(onBack: () -> Unit, onSelect: (ColoringPage) -> Unit) {
    var selectedCategory by remember { mutableStateOf("すべて") }
    val filtered = if (selectedCategory == "すべて") pages else pages.filter { it.category == selectedCategory }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ぬりえをえらぶ", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Cream)
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Text(
                "カテゴリーからえらべるよ",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Ink,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedCategory == "すべて",
                        onClick = { selectedCategory = "すべて" },
                        label = { Text("すべて 1000") }
                    )
                }
                items(categories.size) { i ->
                    val category = categories[i]
                    FilterChip(
                        selected = selectedCategory == category,
                        onClick = { selectedCategory = category },
                        label = { Text("${categoryEmoji[i]} $category") }
                    )
                }
            }
            Text(
                "${filtered.size}種類",
                fontSize = 13.sp,
                color = PinkDark,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filtered, key = { it.id }) { page ->
                    Card(
                        onClick = { onSelect(page) },
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(3.dp)
                    ) {
                        Column(
                            Modifier.fillMaxWidth().padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                Modifier.fillMaxWidth().aspectRatio(1f)
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(Color(0xFFFFFBFD)),
                                contentAlignment = Alignment.Center
                            ) {
                                Canvas(Modifier.fillMaxSize().padding(10.dp)) {
                                    drawMiniLineArt(page.template, page.variant)
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(page.title, fontWeight = FontWeight.Bold, color = Ink, maxLines = 1)
                            Spacer(Modifier.height(4.dp))
                            Text("${page.category} / タップしてぬる", fontSize = 12.sp, color = PinkDark)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PaintScreen(
    page: ColoringPage,
    soundOn: Boolean,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val context = LocalContext.current
    val strokes = remember { mutableStateListOf<StrokeData>() }
    val undone = remember { mutableStateListOf<StrokeData>() }
    var selectedColor by remember { mutableStateOf(palette.first()) }
    var brushWidth by remember { mutableStateOf(26f) }
    var eraser by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    fun feedback() {
        if (!soundOn) return
        val vibrator = if (android.os.Build.VERSION.SDK_INT >= 31) {
            context.getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        vibrator.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${page.emoji} ${page.title}", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = {
                        if (strokes.isNotEmpty()) {
                            undone.add(strokes.removeLast())
                            feedback()
                        }
                    }) { Icon(Icons.Default.Undo, null) }
                    IconButton(onClick = {
                        if (undone.isNotEmpty()) {
                            strokes.add(undone.removeLast())
                            feedback()
                        }
                    }) { Icon(Icons.Default.Redo, null) }
                    IconButton(onClick = {
                        saveArtwork(context, page, strokes.toList())
                        message = "保存しました！"
                        onSaved()
                        feedback()
                    }) { Icon(Icons.Default.Save, null) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Cream)
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 10.dp)) {
            if (message.isNotEmpty()) {
                Text(message, color = PinkDark, fontWeight = FontWeight.Bold, modifier = Modifier.padding(8.dp))
                LaunchedEffect(message) {
                    kotlinx.coroutines.delay(1300)
                    message = ""
                }
            }
            Card(
                modifier = Modifier.fillMaxWidth().weight(1f),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Box(
                    Modifier.fillMaxSize().padding(8.dp)
                ) {
                    Canvas(
                        Modifier.fillMaxSize()
                            .pointerInput(eraser, selectedColor, brushWidth) {
                                detectDragGestures(
                                    onDragStart = { pos ->
                                        undone.clear()
                                        strokes.add(
                                            StrokeData(
                                                listOf(pos),
                                                if (eraser) Color.White else selectedColor,
                                                if (eraser) max(brushWidth * 1.7f, 40f) else brushWidth
                                            )
                                        )
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        val last = strokes.lastOrNull() ?: return@detectDragGestures
                                        strokes[strokes.lastIndex] = last.copy(
                                            points = last.points + (last.points.last() + dragAmount)
                                        )
                                    },
                                    onDragEnd = { feedback() }
                                )
                            }
                    ) {
                        drawRect(Color.White)
                        drawStrokeLayer(strokes)
                        drawLineArt(page.template, page.variant)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Palette, null, tint = PinkDark)
                LazyRow(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    lazyItems(palette) { color ->
                        ColorButton(color, color == selectedColor && !eraser) {
                            selectedColor = color
                            eraser = false
                            feedback()
                        }
                    }
                }
                IconButton(onClick = { eraser = !eraser; feedback() }) {
                    Icon(Icons.Default.Delete, null, tint = if (eraser) PinkDark else Ink)
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("太さ", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                listOf(14f to "細", 26f to "中", 44f to "太").forEach { (width, label) ->
                    FilterChip(
                        selected = brushWidth == width && !eraser,
                        onClick = { brushWidth = width; eraser = false; feedback() },
                        label = { Text(label) },
                        modifier = Modifier.padding(start = 6.dp)
                    )
                }
                Spacer(Modifier.weight(1f))
                Text(if (eraser) "消しゴム" else "ぬりぬり中", color = PinkDark, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun ColorButton(color: Color, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(if (selected) 36.dp else 31.dp)
            .clip(CircleShape)
            .background(color)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (selected) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(if (color.luminance() > 0.6f) Ink else Color.White))
        }
    }
}

@Composable
private fun GalleryScreen(refreshKey: Int, onBack: () -> Unit) {
    val context = LocalContext.current
    var files by remember(refreshKey) { mutableStateOf(loadSavedFiles(context)) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("保存した作品", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
                actions = { Icon(Icons.Default.Folder, null, tint = PinkDark) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Cream)
            )
        }
    ) { padding ->
        if (files.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(padding),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("まだ作品がありません", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("ぬりえを保存すると、ここに表示されます。", color = Color.Gray)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(padding)
            ) {
                items(files, key = { it.absolutePath }) { file ->
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column {
                            androidx.compose.foundation.Image(
                                bitmap = android.graphics.BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap()
                                    ?: return@Column,
                                contentDescription = file.name,
                                modifier = Modifier.fillMaxWidth().aspectRatio(1f)
                            )
                            Row(
                                Modifier.fillMaxWidth().padding(8.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(file.nameWithoutExtension, fontSize = 11.sp, maxLines = 1, modifier = Modifier.weight(1f))
                                IconButton(onClick = { setAsHomeWallpaper(context, file) }) {
                                    Icon(Icons.Default.Wallpaper, contentDescription = "ホーム画面に設定", tint = PinkDark)
                                }
                                IconButton(onClick = {
                                    file.delete()
                                    files = loadSavedFiles(context)
                                }) {
                                    Icon(Icons.Default.Delete, null, tint = PinkDark)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun setAsHomeWallpaper(context: Context, file: File) {
    try {
        val manager = WallpaperManager.getInstance(context)
        FileInputStream(file).use { input ->
            manager.setStream(input, null, true, WallpaperManager.FLAG_SYSTEM)
        }
        Toast.makeText(context, "ホーム画面の待ち受けに設定しました", Toast.LENGTH_SHORT).show()
    } catch (e: IOException) {
        Toast.makeText(context, "待ち受け設定に失敗しました", Toast.LENGTH_SHORT).show()
    }
}

private fun loadSavedFiles(context: Context): List<File> =
    context.filesDir.listFiles { f -> f.extension == "png" }?.sortedByDescending { it.lastModified() } ?: emptyList()

private fun saveArtwork(context: Context, page: ColoringPage, strokes: List<StrokeData>) {
    val w = 1000
    val h = 1300
    val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)

    val p = AndroidPaint().apply {
        isAntiAlias = true
        style = AndroidPaint.Style.STROKE
        strokeCap = AndroidPaint.Cap.ROUND
        strokeJoin = AndroidPaint.Join.ROUND
    }

    val sx = w / 1000f
    val sy = h / 1300f
    strokes.forEach { stroke ->
        if (stroke.points.isEmpty()) return@forEach
        p.color = stroke.color.toArgb()
        p.strokeWidth = stroke.width * sx
        val path = AndroidPath()
        path.moveTo(stroke.points.first().x / 1f * sx, stroke.points.first().y / 1f * sy)
        stroke.points.drop(1).forEach { pt -> path.lineTo(pt.x * sx, pt.y * sy) }
        canvas.drawPath(path, p)
    }

    val line = AndroidPaint().apply {
        isAntiAlias = true
        style = AndroidPaint.Style.STROKE
        strokeWidth = 8f
        color = android.graphics.Color.rgb(50, 46, 54)
        strokeCap = AndroidPaint.Cap.ROUND
        strokeJoin = AndroidPaint.Join.ROUND
    }
    drawAndroidLineArt(canvas, page.template, page.variant, w.toFloat(), h.toFloat(), line)

    val file = File(context.filesDir, "art_${System.currentTimeMillis()}.png")
    FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    bitmap.recycle()
}

private fun drawAndroidLineArt(c: AndroidCanvas, template: Int, variant: Int, w: Float, h: Float, p: AndroidPaint) {
    val cx = w / 2f
    val v = variant % 100
    val wobble = (v % 10 - 5) * 7f
    val scale = 0.88f + (v % 7) * 0.025f
    when (template) {
        1 -> { // flower
            val cy=h*.43f; val r=120f*scale
            c.drawCircle(cx+wobble,cy,r,p)
            for(i in 0 until 8){ val a=i*Math.PI/4; c.drawCircle(cx+wobble+kotlin.math.cos(a).toFloat()*r*1.15f,cy+kotlin.math.sin(a).toFloat()*r*1.15f,r*.62f,p) }
            c.drawLine(cx+wobble,cy+r,cx+wobble+v%3*30f,h*.86f,p)
            c.drawOval(RectF(cx-120+wobble,h*.65f,cx+20+wobble,h*.78f),p)
        }
        2 -> { // cat
            val cy=h*.48f; val r=170f*scale
            c.drawCircle(cx+wobble,cy,r,p)
            val l=AndroidPath().apply{moveTo(cx-r*.75f+wobble,cy-r*.65f);lineTo(cx-r*.35f+wobble,cy-r*1.15f);lineTo(cx-r*.05f+wobble,cy-r*.75f);close()}; c.drawPath(l,p)
            val rr=AndroidPath().apply{moveTo(cx+r*.75f+wobble,cy-r*.65f);lineTo(cx+r*.35f+wobble,cy-r*1.15f);lineTo(cx+r*.05f+wobble,cy-r*.75f);close()}; c.drawPath(rr,p)
            c.drawCircle(cx-60+wobble,cy-20,12f,p); c.drawCircle(cx+60+wobble,cy-20,12f,p)
            c.drawCircle(cx+wobble,cy+20,10f,p)
        }
        3 -> { // rocket
            val path=AndroidPath(); path.moveTo(cx+wobble,h*.16f);path.lineTo(cx+130*scale+wobble,h*.40f);path.lineTo(cx+105*scale+wobble,h*.75f);path.lineTo(cx-105*scale+wobble,h*.75f);path.lineTo(cx-130*scale+wobble,h*.40f);path.close();c.drawPath(path,p)
            c.drawCircle(cx+wobble,h*.46f,45f*scale,p)
            c.drawLine(cx-75+wobble,h*.74f,cx-130+wobble,h*.90f,p);c.drawLine(cx+75+wobble,h*.74f,cx+130+wobble,h*.90f,p)
        }
        4 -> { // car
            c.drawRoundRect(RectF(cx-270*scale+wobble,h*.47f,cx+270*scale+wobble,h*.69f),60f,60f,p)
            c.drawCircle(cx-155*scale+wobble,h*.70f,55f*scale,p);c.drawCircle(cx+155*scale+wobble,h*.70f,55f*scale,p)
            val roof=AndroidPath();roof.moveTo(cx-160*scale+wobble,h*.47f);roof.lineTo(cx-70*scale+wobble,h*.33f);roof.lineTo(cx+120*scale+wobble,h*.33f);roof.lineTo(cx+180*scale+wobble,h*.47f);c.drawPath(roof,p)
        }
        5 -> { // dinosaur
            c.drawOval(RectF(cx-260*scale+wobble,h*.40f,cx+210*scale+wobble,h*.65f),p);c.drawCircle(cx+245*scale+wobble,h*.42f,90f*scale,p)
            repeat(3){i->c.drawLine(cx-150*scale+i*120*scale+wobble,h*.62f,cx-180*scale+i*130*scale+wobble,h*.84f,p)}
            c.drawCircle(cx+280*scale+wobble,h*.42f,8f,p)
        }
        6 -> { // house/rainbow
            c.drawRect(cx-230*scale+wobble,h*.50f,cx+230*scale+wobble,h*.82f,p);val roof=AndroidPath();roof.moveTo(cx-280*scale+wobble,h*.50f);roof.lineTo(cx+wobble,h*.25f);roof.lineTo(cx+280*scale+wobble,h*.50f);roof.close();c.drawPath(roof,p);c.drawRect(cx-50+wobble,h*.64f,cx+50+wobble,h*.82f,p);c.drawCircle(cx+260+wobble,h*.20f,85f,p);c.drawArc(RectF(cx-350+wobble,h*.05f,cx+350+wobble,h*.45f),190f,160f,false,p)
        }
        7 -> { // unicorn
            c.drawOval(RectF(cx-220*scale+wobble,h*.42f,cx+170*scale+wobble,h*.67f),p);c.drawCircle(cx+205*scale+wobble,h*.39f,85f*scale,p);val horn=AndroidPath();horn.moveTo(cx+220*scale+wobble,h*.32f);horn.lineTo(cx+260*scale+wobble,h*.13f);horn.lineTo(cx+180*scale+wobble,h*.30f);c.drawPath(horn,p);c.drawLine(cx-130*scale+wobble,h*.62f,cx-150*scale+wobble,h*.85f,p);c.drawLine(cx+40*scale+wobble,h*.62f,cx+20*scale+wobble,h*.85f,p)
        }
        8 -> { // cake
            c.drawRoundRect(RectF(cx-230*scale+wobble,h*.45f,cx+230*scale+wobble,h*.76f),35f,35f,p);c.drawRoundRect(RectF(cx-180*scale+wobble,h*.32f,cx+180*scale+wobble,h*.50f),30f,30f,p);c.drawLine(cx+wobble,h*.31f,cx+wobble,h*.16f,p);c.drawCircle(cx+wobble,h*.12f,18f,p)
        }
        9 -> { // rainbow + clouds
            for(i in 0 until 5) c.drawArc(RectF(cx-320*scale+wobble,h*.18f-i*12,cx+320*scale+wobble,h*.78f+i*12),200f,140f,false,p)
            c.drawCircle(cx-250+wobble,h*.67f,55f,p);c.drawCircle(cx-190+wobble,h*.65f,70f,p);c.drawCircle(cx+250+wobble,h*.67f,55f,p);c.drawCircle(cx+190+wobble,h*.65f,70f,p)
        }
        10 -> { // whale
            c.drawOval(RectF(cx-300*scale+wobble,h*.40f,cx+220*scale+wobble,h*.68f),p);val tail=AndroidPath();tail.moveTo(cx+210*scale+wobble,h*.53f);tail.lineTo(cx+320*scale+wobble,h*.40f);tail.lineTo(cx+285*scale+wobble,h*.55f);tail.lineTo(cx+320*scale+wobble,h*.68f);tail.close();c.drawPath(tail,p);c.drawCircle(cx-210*scale+wobble,h*.47f,10f,p);c.drawArc(RectF(cx-40+wobble,h*.05f,cx+40+wobble,h*.25f),180f,180f,false,p)
        }
    }
}

private fun saveStrokePath(scope: DrawScope, stroke: StrokeData) {
    if (stroke.points.isEmpty()) return
    val path = Path().apply {
        moveTo(stroke.points.first().x, stroke.points.first().y)
        stroke.points.drop(1).forEach { lineTo(it.x, it.y) }
    }
    scope.drawPath(
        path = path,
        color = stroke.color,
        style = Stroke(width = stroke.width, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
}

private fun DrawScope.drawStrokeLayer(strokes: List<StrokeData>) {
    strokes.forEach { saveStrokePath(this, it) }
}

private fun DrawScope.drawLineArt(template: Int, variant: Int) {
    val ink=Color(0xFF3C3840); val s=size.minDimension; val cx=size.width/2f; val v=variant%100; val wobble=(v%10-5)*s*.012f; val scale=.88f+(v%7)*.025f
    fun c(x:Float,y:Float,r:Float)=drawCircle(ink,r,Offset(x,y),style=Stroke(6f))
    when(template){
        1->{val cy=size.height*.43f;val r=s*.13f*scale;c(cx+wobble,cy,r);repeat(8){i->val a=i*Math.PI/4; c(cx+wobble+kotlin.math.cos(a).toFloat()*r*1.15f,cy+kotlin.math.sin(a).toFloat()*r*1.15f,r*.62f)};drawLine(ink,Offset(cx+wobble,cy+r),Offset(cx+wobble,size.height*.86f),7f);drawOval(ink,Offset(cx-s*.10f+wobble,size.height*.65f),Size(s*.16f,s*.09f),style=Stroke(6f))}
        2->{val cy=size.height*.48f;val r=s*.15f*scale;c(cx+wobble,cy,r);val l=Path().apply{moveTo(cx-r*.75f+wobble,cy-r*.65f);lineTo(cx-r*.35f+wobble,cy-r*1.15f);lineTo(cx-r*.05f+wobble,cy-r*.75f);close()};drawPath(l,ink,style=Stroke(6f));val rr=Path().apply{moveTo(cx+r*.75f+wobble,cy-r*.65f);lineTo(cx+r*.35f+wobble,cy-r*1.15f);lineTo(cx+r*.05f+wobble,cy-r*.75f);close()};drawPath(rr,ink,style=Stroke(6f));c(cx-s*.055f+wobble,cy-s*.01f,s*.012f);c(cx+s*.055f+wobble,cy-s*.01f,s*.012f)}
        3->{val p=Path().apply{moveTo(cx+wobble,size.height*.16f);lineTo(cx+s*.11f*scale+wobble,size.height*.40f);lineTo(cx+s*.09f*scale+wobble,size.height*.76f);lineTo(cx-s*.09f*scale+wobble,size.height*.76f);lineTo(cx-s*.11f*scale+wobble,size.height*.40f);close()};drawPath(p,ink,style=Stroke(7f));c(cx+wobble,size.height*.46f,s*.035f);drawLine(ink,Offset(cx-s*.07f+wobble,size.height*.76f),Offset(cx-s*.12f+wobble,size.height*.90f),7f);drawLine(ink,Offset(cx+s*.07f+wobble,size.height*.76f),Offset(cx+s*.12f+wobble,size.height*.90f),7f)}
        4->{drawRoundRect(ink,Offset(cx-s*.24f*scale+wobble,size.height*.47f),Size(s*.48f*scale,s*.22f),androidx.compose.ui.geometry.CornerRadius(s*.05f),style=Stroke(7f));c(cx-s*.15f*scale+wobble,size.height*.70f,s*.055f*scale);c(cx+s*.15f*scale+wobble,size.height*.70f,s*.055f*scale);drawLine(ink,Offset(cx-s*.14f*scale+wobble,size.height*.47f),Offset(cx-s*.07f*scale+wobble,size.height*.33f),7f);drawLine(ink,Offset(cx-s*.07f*scale+wobble,size.height*.33f),Offset(cx+s*.10f*scale+wobble,size.height*.33f),7f);drawLine(ink,Offset(cx+s*.10f*scale+wobble,size.height*.33f),Offset(cx+s*.17f*scale+wobble,size.height*.47f),7f)}
        5->{drawOval(ink,Offset(cx-s*.24f*scale+wobble,size.height*.40f),Size(s*.47f*scale,s*.25f),style=Stroke(7f));c(cx+s*.25f*scale+wobble,size.height*.44f,s*.09f*scale);repeat(3){i->drawLine(ink,Offset(cx-s*.16f*scale+i*s*.12f*scale+wobble,size.height*.62f),Offset(cx-s*.19f*scale+i*s*.13f*scale+wobble,size.height*.84f),7f)}}
        6->{drawRect(ink,Offset(cx-s*.23f*scale+wobble,size.height*.50f),Size(s*.46f*scale,size.height*.32f),style=Stroke(7f));val roof=Path().apply{moveTo(cx-s*.28f*scale+wobble,size.height*.50f);lineTo(cx+wobble,size.height*.25f);lineTo(cx+s*.28f*scale+wobble,size.height*.50f);close()};drawPath(roof,ink,style=Stroke(7f));drawRect(ink,Offset(cx-s*.05f+wobble,size.height*.64f),Size(s*.10f,size.height*.18f),style=Stroke(6f));c(cx+s*.26f+wobble,size.height*.20f,s*.085f)}
        7->{drawOval(ink,Offset(cx-s*.22f*scale+wobble,size.height*.42f),Size(s*.39f*scale,s*.25f),style=Stroke(7f));c(cx+s*.25f*scale+wobble,size.height*.39f,s*.085f*scale);val horn=Path().apply{moveTo(cx+s*.27f*scale+wobble,size.height*.32f);lineTo(cx+s*.31f*scale+wobble,size.height*.13f);lineTo(cx+s*.22f*scale+wobble,size.height*.30f)};drawPath(horn,ink,style=Stroke(6f));drawLine(ink,Offset(cx-s*.13f*scale+wobble,size.height*.62f),Offset(cx-s*.15f*scale+wobble,size.height*.85f),7f)}
        8->{drawRoundRect(ink,Offset(cx-s*.23f*scale+wobble,size.height*.45f),Size(s*.46f*scale,size.height*.31f),androidx.compose.ui.geometry.CornerRadius(s*.04f),style=Stroke(7f));drawRoundRect(ink,Offset(cx-s*.18f*scale+wobble,size.height*.32f),Size(s*.36f*scale,size.height*.18f),androidx.compose.ui.geometry.CornerRadius(s*.03f),style=Stroke(7f));drawLine(ink,Offset(cx+wobble,size.height*.31f),Offset(cx+wobble,size.height*.16f),6f);c(cx+wobble,size.height*.12f,s*.018f)}
        9->{repeat(5){i->drawArc(ink,Offset(cx-s*.32f*scale+wobble,size.height*.18f-i*10),Size(s*.64f*scale,size.height*.60f+i*20),200f,140f,false,style=Stroke(6f))};c(cx-s*.25f+wobble,size.height*.67f,s*.055f);c(cx-s*.19f+wobble,size.height*.65f,s*.07f);c(cx+s*.25f+wobble,size.height*.67f,s*.055f);c(cx+s*.19f+wobble,size.height*.65f,s*.07f)}
        10->{drawOval(ink,Offset(cx-s*.30f*scale+wobble,size.height*.40f),Size(s*.52f*scale,s*.28f),style=Stroke(7f));val tail=Path().apply{moveTo(cx+s*.21f*scale+wobble,size.height*.53f);lineTo(cx+s*.32f*scale+wobble,size.height*.40f);lineTo(cx+s*.285f*scale+wobble,size.height*.55f);lineTo(cx+s*.32f*scale+wobble,size.height*.68f);close()};drawPath(tail,ink,style=Stroke(6f));c(cx-s*.21f*scale+wobble,size.height*.47f,s*.01f)}
    }
}

private fun DrawScope.drawMiniLineArt(template: Int, variant: Int) { drawLineArt(template, variant) }

private fun DrawScope.drawFlowerScene() {
    val center = Offset(size.width/2f, size.height*.46f)
    val r = size.minDimension*.13f
    repeat(8) { i ->
        val a=(i*Math.PI/4)
        drawCircle(Color(0xFFFFD1E3), r*.85f, Offset(center.x+kotlin.math.cos(a).toFloat()*r*1.35f, center.y+kotlin.math.sin(a).toFloat()*r*1.35f))
    }
    drawCircle(Color(0xFFFFE16B), r, center)
    drawCircle(Color.White, r*.18f, center)
    drawLine(Color(0xFF61B86B), Offset(center.x,center.y+r), Offset(center.x,size.height*.85f), 18f)
    drawOval(Color(0xFF8ED18B), topLeft=Offset(center.x-r*.1f,size.height*.64f), size=Size(r*1.7f,r*.65f))
}