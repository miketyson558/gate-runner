// Build: node build.js  ->  dist/sekai-isan-kentei.html (single self-contained file)
const fs=require("fs"),path=require("path");
const src=p=>fs.readFileSync(path.join(__dirname,"src",p),"utf8");
const js=fs.readdirSync(path.join(__dirname,"src")).filter(f=>/^\d+-.*\.js$/.test(f)).sort().map(src).join("\n");
const html=src("template.html").replace("/*@@CSS@@*/",()=>src("style.css")).replace("/*@@JS@@*/",()=>"\n"+js+"\n");
fs.mkdirSync(path.join(__dirname,"dist"),{recursive:true});
fs.writeFileSync(path.join(__dirname,"dist","sekai-isan-kentei.html"),html);
console.log("built dist/sekai-isan-kentei.html ("+html.length+" bytes)");
