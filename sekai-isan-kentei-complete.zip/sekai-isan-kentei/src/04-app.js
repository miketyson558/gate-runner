/* ---------- State & Storage ---------- */
const DEF = {bgm:true, bt:0, se:true, vol:0.55, grade:"all", mode:"random", field:"all", lang:"auto", goal:20, trapOnly:false, voice:true, voiceAuto:true};
let DB = {prog:{}, bm:{}, today:{d:"",n:0,c:0,s:0}, set:Object.assign({},DEF), last:null};
try{
  const raw = localStorage.getItem("wh_v5");
  if(raw){
    const o = JSON.parse(raw);
    Object.keys(o).forEach(k=> DB[k]=o[k]);
    DB.set = Object.assign({}, DEF, DB.set);
  }
}catch(e){}

function save(){ try{ localStorage.setItem("wh_v5", JSON.stringify(DB)); }catch(e){} }
function tdy(){
  const d=new Date(), s=d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate();
  if(DB.today.d!==s) DB.today={d:s,n:0,c:0,s:0};
  return DB.today;
}


/* ---------- Custom questions (import from your own study notes) ---------- */
function normGrade(x){ x=String(x||"").replace(/[級\s]/g,"").replace("準1","p1").toLowerCase(); return ["4","3","2","p1","1"].includes(x)?x:"3"; }
function addCustom(r){
  addQ({id:"u_"+hash36(r.q+r.c.join("")),grade:r.g,region:"日本",category:r.cat||"自作",general:true,custom:true,
    question:{ja:r.q,en:r.q},choices:{ja:r.c,en:r.c},answer:r.a,
    heritageName:{ja:"",en:""},country:{ja:"",en:""},year:"",criteria:"",type:"文化遺産",
    explanation:{ja:r.e||"",en:r.e||""},ng:{ja:"",en:""},tip:{ja:"",en:""},isTrap:false});
}
(DB.custom||[]).forEach(addCustom);
function parseCustom(text){
  let ok=0,ng=0; DB.custom=DB.custom||[];
  String(text||"").split(/\r?\n/).forEach(line=>{
    line=line.trim(); if(!line||line[0]==="#") return;
    const f=line.split(/\||\t/).map(x=>x.trim());
    if(f.length<8){ ng++; return; }
    const c=f.slice(3,7).filter(Boolean), a=parseInt(f[7],10)-1;
    if(!f[2]||c.length<2||!(a>=0&&a<c.length)){ ng++; return; }
    const r={g:normGrade(f[0]),cat:f[1],q:f[2],c,a,e:f[8]||""};
    if(DB.custom.some(x=>x.q===r.q)){ ng++; return; }
    DB.custom.push(r); addCustom(r); ok++;
  });
  save(); return {ok,ng};
}
function doImport(){
  const el=document.getElementById("imp"); const r=parseCustom(el?el.value:"");
  st.impMsg=`${r.ok} ${curLang==="ja"?"問を追加 / 失敗または重複":"added / failed or duplicate"}: ${r.ng}`; if(el) el.value=""; render();
}
function clearCustom(){
  if(!confirm(curLang==="ja"?"追加した問題をすべて削除しますか？":"Delete all added questions?")) return;
  for(let i=Q.length-1;i>=0;i--) if(Q[i].custom) Q.splice(i,1);
  DB.custom=[]; save(); st.impMsg=""; render();
}
function importScr(){
  const ja=curLang==="ja", n=(DB.custom||[]).length;
  return `<div class="sb"><button onclick="go('home')">←</button><div class="st">${ja?"問題を追加":"Add questions"}</div><span></span></div>
  <main><div class="card"><p style="font-size:13px;color:var(--sub);margin-bottom:8px">${ja?"お手持ちの教材・メモから作った問題を貼り付けます。1行1問、区切りは「|」またはタブ。":"Paste questions from your own notes. One per line, separated by | or tab."}</p>
  <p style="font-size:12px;margin-bottom:8px;font-family:monospace;word-break:break-all">${ja?"級|分類|問題|選択肢1|選択肢2|選択肢3|選択肢4|正解番号(1-4)|解説":"level|category|question|c1|c2|c3|c4|answer(1-4)|explanation"}</p>
  <p style="font-size:12px;color:var(--sub);margin-bottom:8px;font-family:monospace;word-break:break-all">3級|日本|姫路城の別名はどれか。|白鷺城|烏城|松葉城|浮城|1|白漆喰の外観が白鷺に見える。</p>
  <textarea id="imp" rows="8" style="width:100%;background:var(--card2);color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:10px;font-size:14px;cursor:text"></textarea>
  <div class="row" style="margin-top:10px"><button class="btn primary" onclick="doImport()">${ja?"追加":"Add"}</button><button class="btn ghost" onclick="clearCustom()">${ja?"追加分を全削除":"Delete all added"}</button></div>
  <p style="margin-top:10px;font-size:13px">${ja?"追加済み":"Added"}: ${n}${t("qunit")} ${st.impMsg?"· "+esc(st.impMsg):""}</p></div></main>`;
}

/* Language init */
function initLang(){
  let l = DB.set.lang;
  if(l==="auto" || !l){
    const nav = (navigator.language||navigator.userLanguage||"ja").toLowerCase();
    const map = {ja:"ja",en:"en",fr:"fr",pt:"pt",es:"es",zh:"zh",ko:"ko",de:"de",it:"it",ar:"ar",hi:"hi",ru:"ru",th:"th",id:"id",tr:"tr","zh-cn":"zh","zh-tw":"zh","pt-br":"pt","pt-pt":"pt"};
    l = "en";
    for(const [k,v] of Object.entries(map)){ if(nav.startsWith(k)){ l=v; break; } }
  }
  curLang = (LANGS[l] ? l : "en");
  document.documentElement.lang = curLang;
  document.documentElement.dir = (curLang==="ar" ? "rtl" : "ltr");
  try{ _voiceNote = ""; }catch(e){}
  try{ if(typeof loadVoices==="function") loadVoices(); }catch(e){}
  try{ if(typeof _rec!=="undefined" && _rec && typeof preferredBCP47==="function") _rec.lang = preferredBCP47(); }catch(e){}
}
initLang();

/* ---------- Audio (Web Audio) ---------- */
let AC=null, master=null, bgmTimer=null;
const BGM = [
  {n:"Soft Pad", beat:2.8, ch:[[261.6,329.6,392],[220,261.6,329.6],[174.6,220,261.6],[196,246.9,293.7]], sc:[523.3,587.3,659.3,784]},
  {n:"Ambient", beat:3.3, ch:[[196,293.7,392],[174.6,261.6,349.2],[220,329.6,440],[164.8,246.9,329.6]], sc:[392,440,493.9,587.3]},
  {n:"Calm Night", beat:3.0, ch:[[220,261.6,329.6],[174.6,220,261.6],[261.6,329.6,392],[164.8,196,246.9]], sc:[440,523.3,587.3,659.3]}
];
function ac(){
  if(!AC){
    const C = window.AudioContext||window.webkitAudioContext;
    if(!C) return null;
    AC = new C();
    master = AC.createGain();
    master.gain.value = DB.set.vol;
    master.connect(AC.destination);
  }
  return AC;
}
function tone(freq, dur, type="sine", vol=0.15, when=0, bg=false){
  const ctx=ac(); if(!ctx||(!bg && !DB.set.se)) return;
  const o=ctx.createOscillator(), g=ctx.createGain();
  o.type=type; o.frequency.value=freq;
  g.gain.setValueAtTime(vol, ctx.currentTime+when);
  g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime+when+dur);
  o.connect(g); g.connect(master);
  o.start(ctx.currentTime+when); o.stop(ctx.currentTime+when+dur+0.05);
}
function playOK(){ tone(523.3,0.12,"sine",0.12); tone(659.3,0.18,"sine",0.1,0.1); }
function playNG(){ tone(200,0.25,"triangle",0.12); }
function bgmTick(){
  if(!DB.set.bgm) return;
  const ctx=ac(); if(!ctx) return;
  const T=BGM[DB.set.bt%BGM.length];
  const ch=T.ch[Math.floor(Math.random()*T.ch.length)];
  ch.forEach((f,i)=> tone(f, T.beat*0.9, "sine", 0.03, i*0.02, true));
  if(Math.random()>0.6){
    const sc=T.sc[Math.floor(Math.random()*T.sc.length)];
    tone(sc, 0.4, "triangle", 0.04, 0.15, true);
  }
}
function bgmStart(){
  if(bgmTimer||!DB.set.bgm) return;
  const T=BGM[DB.set.bt%BGM.length];
  bgmTick();
  bgmTimer=setInterval(bgmTick, T.beat*1000);
}
function bgmStop(){ if(bgmTimer){clearInterval(bgmTimer);bgmTimer=null;} }

/* ---------- Voice (Web Speech API) — TTS + Speech Recognition ---------- */
const VOICE_LANG_MAP = {
  ja:"ja-JP", en:"en-US", fr:"fr-FR", pt:"pt-BR", es:"es-ES",
  zh:"zh-CN", ko:"ko-KR", de:"de-DE", it:"it-IT",
  ar:"ar-SA", hi:"hi-IN", ru:"ru-RU", th:"th-TH", id:"id-ID", tr:"tr-TR"
};
let _speaking = false;
let _voices = [];
let _voiceNote = "";          // transient UI note about voice availability
let _listenState = "idle";    // idle | listening | processing | error
let _listenText = "";         // last recognized text
let _rec = null;              // SpeechRecognition instance

function loadVoices(){
  try{
    if(window.speechSynthesis) _voices = speechSynthesis.getVoices() || [];
  }catch(e){ _voices = []; }
}
if(typeof window !== "undefined" && window.speechSynthesis){
  loadVoices();
  speechSynthesis.onvoiceschanged = loadVoices;
}

function preferredBCP47(){
  return VOICE_LANG_MAP[curLang] || "en-US";
}

/** Find best matching voice: exact lang → language prefix → null */
function findBestVoice(langCode){
  if(!_voices.length) loadVoices();
  if(!_voices.length) return null;
  const norm = s => String(s||"").toLowerCase().replace("_","-");
  const target = norm(langCode);
  const prefix = target.split("-")[0];
  // 1) exact match
  let v = _voices.find(x => norm(x.lang) === target);
  if(v) return v;
  // 2) same language family (pt-BR / pt-PT, zh-CN / zh-TW, etc.)
  v = _voices.find(x => norm(x.lang).startsWith(prefix + "-") || norm(x.lang) === prefix);
  if(v) return v;
  // 3) any voice whose lang starts with the prefix
  v = _voices.find(x => norm(x.lang).startsWith(prefix));
  return v || null;
}

function voiceLang(){
  return preferredBCP47();
}

function stopSpeak(){
  try{ if(window.speechSynthesis) speechSynthesis.cancel(); }catch(e){}
  _speaking = false;
}

function speakText(text, opts){
  if(!DB.set.voice || !text || !window.speechSynthesis) return;
  stopSpeak();
  const langCode = preferredBCP47();
  const voice = findBestVoice(langCode);
  const u = new SpeechSynthesisUtterance(String(text));
  u.lang = langCode;
  if(voice){
    u.voice = voice;
    _voiceNote = "";
  }else{
    // No matching voice installed — keep the requested lang so the engine may still try,
    // and surface a clear notice instead of silently forcing English.
    _voiceNote = (curLang==="ja")
      ? `この端末に「${curLang}」用の音声がありません。端末の設定で音声を追加するか、別の言語を選んでください。`
      : `No speech voice for “${curLang}” is installed on this device. The system may fall back to another voice.`;
  }
  u.rate = (opts && opts.rate) || 0.95;
  u.pitch = 1;
  u.volume = Math.max(0.2, Math.min(1, DB.set.vol || 0.8));
  u.onend = u.onerror = ()=>{ _speaking = false; };
  _speaking = true;
  setTimeout(()=>{
    try{ speechSynthesis.speak(u); }catch(e){ _speaking = false; }
  }, 40);
  // brief note in UI
  if(_voiceNote) setTimeout(()=>{ try{ render(); }catch(e){} }, 50);
}

function speakQuestion(q){
  if(!q || !DB.set.voice) return;
  const qtext = tt(q.question);
  const choices = choicesOf(q);
  let body = qtext;
  if(choices.length){
    body += ". " + choices.map((c,i)=> String.fromCharCode(65+i) + ". " + c).join(". ");
  }
  speakText(body);
}

function speakExplanation(q){
  if(!q || !DB.set.voice) return;
  const parts = [
    tt(q.heritageName),
    tt(q.country),
    (q.year ? String(q.year) : ""),
    tt(q.explanation)
  ].filter(Boolean);
  speakText(parts.join(". "));
}

/* ----- Speech Recognition (talk to answer / commands) ----- */
function hasSpeechRecognition(){
  return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
}

function ensureRecognition(){
  if(_rec) return _rec;
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if(!SR) return null;
  _rec = new SR();
  _rec.continuous = false;
  _rec.interimResults = true;
  _rec.maxAlternatives = 3;
  _rec.onstart = ()=>{ _listenState = "listening"; _listenText = ""; try{render();}catch(e){} };
  _rec.onresult = (ev)=>{
    let interim = "", final = "";
    for(let i = ev.resultIndex; i < ev.results.length; i++){
      const r = ev.results[i];
      if(r.isFinal) final += r[0].transcript;
      else interim += r[0].transcript;
    }
    _listenText = (final || interim).trim();
    if(final){
      _listenState = "processing";
      try{render();}catch(e){}
      handleVoiceInput(final.trim());
    }else{
      try{render();}catch(e){}
    }
  };
  _rec.onerror = (ev)=>{
    _listenState = "error";
    const code = (ev && ev.error) || "";
    if(code === "not-allowed" || code === "service-not-allowed"){
      _listenText = curLang==="ja" ? "マイクの許可が必要です" : "Microphone permission required";
    }else if(code === "no-speech"){
      _listenText = curLang==="ja" ? "音声が検出されませんでした" : "No speech detected";
    }else{
      _listenText = curLang==="ja" ? "認識エラー: " + code : "Recognition error: " + code;
    }
    try{render();}catch(e){}
    setTimeout(()=>{ _listenState = "idle"; try{render();}catch(e){} }, 2500);
  };
  _rec.onend = ()=>{
    if(_listenState === "listening") _listenState = "idle";
    try{render();}catch(e){}
  };
  return _rec;
}

function startListening(){
  if(!hasSpeechRecognition()){
    _listenState = "error";
    _listenText = curLang==="ja" ? "このブラウザは音声認識に対応していません" : "Speech recognition is not supported in this browser";
    try{render();}catch(e){}
    setTimeout(()=>{ _listenState = "idle"; try{render();}catch(e){} }, 3000);
    return;
  }
  stopSpeak(); // stop TTS while listening
  const r = ensureRecognition();
  if(!r) return;
  try{
    r.lang = preferredBCP47();
    if(_listenState === "listening"){
      try{ r.stop(); }catch(e){}
      _listenState = "idle";
      try{render();}catch(e){}
      return;
    }
    r.start();
  }catch(e){
    _listenState = "error";
    _listenText = String(e.message || e);
    try{render();}catch(e){}
  }
}

function stopListening(){
  try{ if(_rec) _rec.stop(); }catch(e){}
  _listenState = "idle";
}

/** Normalize spoken numbers / choice labels across languages */
function parseChoiceIndex(raw){
  const s = String(raw||"").toLowerCase().replace(/\s+/g,"").replace(/[。．.、,]/g,"");
  // digit / letter
  if(/^[1-4]$/.test(s)) return parseInt(s,10) - 1;
  if(/^[a-d]$/.test(s)) return s.charCodeAt(0) - 97;
  // Japanese
  const jaMap = {"いち":0,"一":0,"ひとつ":0,"い":0,"に":1,"二":1,"ふたつ":1,"さん":2,"三":2,"みっつ":2,"よん":3,"し":3,"四":3,"よっつ":3};
  if(jaMap[s] !== undefined) return jaMap[s];
  // English ordinals / words
  const enMap = {"one":0,"first":0,"two":1,"second":1,"three":2,"third":2,"four":3,"fourth":3,"1st":0,"2nd":1,"3rd":2,"4th":3};
  if(enMap[s] !== undefined) return enMap[s];
  // French / Spanish / Portuguese / German / Korean / Chinese (common short forms)
  const multi = {
    "un":0,"uno":0,"um":0,"eins":0,"하나":0,"일":0,"一":0,
    "deux":1,"dos":1,"dois":1,"zwei":1,"둘":1,"이":1,"二":1,
    "trois":2,"tres":2,"três":2,"drei":2,"셋":2,"삼":2,"三":2,
    "quatre":3,"cuatro":3,"quatro":3,"vier":3,"넷":3,"사":3,"四":3
  };
  if(multi[s] !== undefined) return multi[s];
  return -1;
}

function handleVoiceInput(transcript){
  const raw = String(transcript||"").trim();
  if(!raw){ _listenState = "idle"; return; }
  const low = raw.toLowerCase();
  const Z = st.quiz;

  // Global / navigation commands (work even outside answer phase)
  const nextCmds = ["次","次へ","次の問題","つぎ","next","siguiente","suivant","proximo","próximo","weiter","avanti","다음","下一题","下一題"];
  const explainCmds = ["解説","詳しい解説","せつめい","explanation","explain","explicación","explication","explicação","erklärung","spiegazione","해설","解说"];
  const againCmds = ["もう一度","もういちど","再度","again","repeat","もう一回","다시","再来一次"];
  const skipCmds = ["スキップ","とばす","skip","saltar","passer"];
  const bmCmds = ["ブックマーク","お気に入り","bookmark","favorito","favori","즐겨찾기","收藏"];
  const homeCmds = ["ホーム","home","トップ","top"];

  const matchCmd = (list) => list.some(c => low.includes(c.toLowerCase()) || raw.includes(c));

  if(matchCmd(homeCmds)){ stopListening(); go("home"); return; }
  if(matchCmd(againCmds) && Z){ stopListening(); speakQuestion(curQ()); _listenState="idle"; return; }
  if(matchCmd(explainCmds) && Z && Z.picked !== null){ stopListening(); speakExplanation(curQ()); _listenState="idle"; return; }
  if(matchCmd(bmCmds) && Z){ stopListening(); toggleBm(Z.list[Z.i].id); _listenState="idle"; try{render();}catch(e){} return; }
  if(matchCmd(nextCmds) && Z){
    stopListening();
    if(Z.picked === null){ /* force skip? treat as no-op or advance after answer */ }
    else advance();
    _listenState = "idle";
    return;
  }
  if(matchCmd(skipCmds) && Z && Z.picked === null){
    // soft skip: pick nothing, just advance without scoring? keep simple — ignore
  }

  // Answer phase only
  if(!Z || Z.picked !== null){
    _listenState = "idle";
    _listenText = raw;
    try{render();}catch(e){}
    setTimeout(()=>{ _listenState="idle"; try{render();}catch(e){} }, 1800);
    return;
  }

  // 1) explicit number / letter
  let idx = parseChoiceIndex(raw);
  if(idx < 0){
    // try first token
    const first = raw.split(/[\s、。,．]+/)[0];
    idx = parseChoiceIndex(first);
  }

  // 2) match against choice text (partial, case-insensitive)
  if(idx < 0){
    const choices = choicesOf(Z.list[Z.i]);
    const norm = s => String(s||"").toLowerCase().replace(/\s+/g,"");
    const tnorm = norm(raw);
    for(let i=0;i<choices.length;i++){
      const c = norm(choices[i]);
      if(!c) continue;
      if(tnorm.includes(c) || c.includes(tnorm) || (tnorm.length>=2 && c.indexOf(tnorm)>=0)){
        idx = i; break;
      }
      // also try heritage name fragments
      const words = c.split(/[\s・]/);
      if(words.some(w => w.length>=2 && tnorm.includes(norm(w)))){
        idx = i; break;
      }
    }
  }

  if(idx >= 0 && idx <= 3){
    _listenText = raw + " → " + String.fromCharCode(65+idx);
    stopListening();
    pick(idx);
    _listenState = "idle";
  }else{
    _listenText = (curLang==="ja" ? "聞き取れませんでした: " : "Could not match: ") + raw;
    _listenState = "error";
    try{render();}catch(e){}
    setTimeout(()=>{ _listenState="idle"; try{render();}catch(e){} }, 2200);
  }
}

/* ---------- Helpers ---------- */
function $(s){return document.querySelector(s)}
function esc(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}
function shuffle(a){const b=a.slice();for(let i=b.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[b[i],b[j]]=[b[j],b[i]];}return b;}
function gradeClass(g){return g==="4"?"g4":g==="3"?"g3":g==="2"?"g2":g==="p1"?"gp1":"g1";}

function fieldOK(q){
  const f=DB.set.field;
  if(f==="all"||q.general) return true;
  const c = tt(q.country);
  if(f==="jp") return c==="日本"||c==="Japan";
  if(f==="world") return !(c==="日本"||c==="Japan");
  if(f==="cultural") return q.type==="文化遺産";
  return q.type==="自然遺産"||q.type==="複合遺産";
}
const GRANK={4:0,3:1,2:2,p1:3,1:4};
function gradeIn(g){ return DB.set.grade==="all"||GRANK[g]<=GRANK[DB.set.grade]; } // cumulative: higher levels include lower ranges
function gradeOK(q){ return gradeIn(q.grade); }
function pool(){
  return Q.filter(q=> gradeOK(q) && fieldOK(q) && (!DB.set.trapOnly || q.isTrap));
}
function inMode(q,m){
  const p=DB.prog[q.id];
  return m==="random"?true : m==="fresh"?!p : m==="wrong"?(p&&p.l===0) : !!DB.bm[q.id];
}
function modeList(m){ return pool().filter(q=>inMode(q,m)); }

/* ---------- UI State ---------- */
let st = {screen:"home", quiz:null, modal:null, fl:null, toast:null};

function toast(msg){
  st.toast = msg;
  render();
  setTimeout(()=>{st.toast=null;render();}, 2200);
}

/* ---------- Share ---------- */
async function doShare(text){
  if(navigator.share){
    try{ await navigator.share({title:t("title"), text}); return; }catch(e){ if(e.name==="AbortError") return; }
  }
  try{
    await navigator.clipboard.writeText(text);
    toast(t("copied"));
  }catch(e){
    toast(t("shareFail"));
  }
}
function shareProgress(){
  const td=tdy();
  const total=Object.keys(DB.prog).length;
  const correct=Object.values(DB.prog).filter(p=>p.l===1).length;
  const rate=total?Math.round(correct/total*100):0;
  const text = `${t("title")}\n${t("solved")}: ${total}${t("qunit")}\n${t("accuracy")}: ${rate}%\n${t("todayStudy")}: ${td.n}${t("qunit")}`;
  doShare(text);
}
function shareCurrentQ(){
  if(!st.quiz) return;
  const q = st.quiz.list[st.quiz.i];
  const text = `${tt(q.question)}\n\n${choicesOf(q).map((c,i)=>String.fromCharCode(65+i)+". "+c).join("\n")}\n\n${t("detail")}:\n${tt(q.explanation)}`;
  doShare(text);
}

/* ---------- Screens ---------- */
function home(){
  const td=tdy();
  const p=pool();
  const solved=p.filter(q=>DB.prog[q.id]).length;
  const correct=p.filter(q=>DB.prog[q.id]?.l===1).length;
  const rate=solved?Math.round(correct/solved*100):null;
  const modes=[["random",t("modes.random")],["fresh",t("modes.fresh")],["wrong",t("modes.wrong")],["bm",t("modes.bm")]];
  let h=`<div class="card accent">
    <div class="sum">
      <div><small>${t("todayStudy")}</small><b>${td.n}</b><i>${t("qunit")}</i></div>
      <div><small>${t("accuracy")}</small><b>${rate!==null?rate+"%":"—"}</b></div>
    </div>
    <div class="pb"><i style="width:${Math.min(100,td.n/DB.set.goal*100)}%"></i></div>
    <div class="pl">${t("goal")} ${td.n} / ${DB.set.goal}${t("qunit")} · ${t("time")} ${Math.floor((td.s||0)/60)}${t("min")}</div>
    <div class="pl" style="margin-top:6px">${t("solved")} ${solved} / ${p.length}${t("qunit")}</div>
  </div>
  <div class="modes">`;
  modes.forEach(([k,l])=>{
    const cnt=modeList(k).length;
    h+=`<button class="md ${DB.set.mode===k?"on":""}" onclick="setMode('${k}')">${l}<small>${cnt}${t("qunit")}</small></button>`;
  });
  h+=`</div>
  <div class="fld">${t("field")}: <b>${t("fields."+DB.set.field)}</b> <button class="lk" onclick="modal('field')">${t("change")}</button>
  ${DB.set.trapOnly?'<span class="badge trap">'+t("trapBadge")+'</span>':''}
  </div>
  <button class="go" onclick="startQuiz()" ${modeList(DB.set.mode).length===0?"disabled":""}>${t("startRandom")} (${Math.min(10,modeList(DB.set.mode).length)}${t("qunit")})</button>
  <button class="res" onclick="startSmart()">🎯 ${t("startSmart")}</button>
  <div class="menu" style="margin-top:18px">
    <button class="mi" onclick="go('mock')"><span class="e">📝</span><div><b>${t("menu.mock")}</b><small>${t("mockDesc")}</small></div><span class="ar">›</span></button>
    <button class="mi" onclick="go('flash')"><span class="e">🃏</span><div><b>${t("menu.flash")}</b><small>${t("flashDesc")}</small></div><span class="ar">›</span></button>
    <button class="mi" onclick="go('browse')"><span class="e">🔍</span><div><b>${t("menu.browse")}</b><small>${t("browseDesc")}</small></div><span class="ar">›</span></button>
    <button class="mi" onclick="go('report')"><span class="e">📊</span><div><b>${t("menu.report")}</b><small>${t("reportDesc")}</small></div><span class="ar">›</span></button>
    <button class="mi" onclick="go('guide')"><span class="e">📖</span><div><b>${t("menu.guide")}</b><small>${t("guideDesc")}</small></div><span class="ar">›</span></button>
    <button class="mi" onclick="go('import')"><span class="e">➕</span><div><b>${curLang==="ja"?"問題を追加":"Add questions"}</b><small>${curLang==="ja"?"自分の教材から問題を取り込む":"Import your own questions"}</small></div><span class="ar">›</span></button>
  </div>`;
  return h;
}

function setMode(m){ DB.set.mode=m; save(); render(); }
function setGrade(g){ DB.set.grade=g; save(); render(); }

function startQuiz(list){
  const src = list || shuffle(modeList(DB.set.mode)).slice(0,10);
  if(!src.length){ toast(t("noData")); return; }
  st.quiz={list:prepList(src), i:0, picked:null, log:[], mock:false};
  st.screen="quiz";
  bgmStart();
  render();
}
function startSmart(){
  const wrongs=modeList("wrong");
  const low=pool().filter(q=>{const p=DB.prog[q.id];return p&&p.a>=2&&p.c/p.a<0.6;});
  const base=shuffle([...wrongs,...low,...modeList("fresh")]).slice(0,10);
  startQuiz(base.length?base:shuffle(pool()).slice(0,10));
}

function curQ(){ return st.quiz? st.quiz.list[st.quiz.i] : null; }
function critMeaning(c){
  const m=String(c||"").match(/\(([ivx]+)\)/g); if(!m) return "";
  const seen=new Set(); let h="";
  m.forEach(x=>{ const k=x.slice(1,-1); if(seen.has(k)||!CRM[k]) return; seen.add(k); h+=`<div style="font-size:13px;margin-top:3px"><b>(${k})</b> ${esc(tt(CRM[k]))}</div>`; });
  return h? `<div class="dh">${t("criteriaLabel")}</div>${h}` : "";
}
function ell(s,n){ s=String(s||""); return s.length>n? s.slice(0,n)+"…" : s; }
function quiz(){
  const Z=st.quiz;
  if(!Z||!Z.list.length) return "<p>"+t("noData")+"</p>";
  const q=Z.list[Z.i];
  const choices=choicesOf(q);
  const gtag=`<span class="tag ${gradeClass(q.grade)}">${t("grades."+q.grade)}</span>`;
  const trap=q.isTrap?`<span class="tag trap">${t("trapBadge")}</span>`:"";
  const micSupported = hasSpeechRecognition();
  const micLabel = _listenState==="listening" ? "⏹" : "🎤";
  const micTitle = _listenState==="listening"
    ? (curLang==="ja"?"認識を停止":"Stop listening")
    : (curLang==="ja"?"話して答える":"Speak to answer");
  let h=`<div class="sb"><button onclick="go('home');stopSpeak();stopListening()">←</button><div class="st">${Z.i+1} / ${Z.list.length}${Z.deadline?` · ⏱ <span id="tmr">${fmtT(Z.deadline-Date.now())}</span>`:""}</div>
  <button onclick="DB.set.voice&&_speaking?stopSpeak():speakQuestion(curQ())" title="${t('speak')}">${_speaking?'⏹':'🔊'}</button>
  ${micSupported?`<button onclick="startListening()" title="${micTitle}" class="${_listenState==="listening"?"on":""}">${micLabel}</button>`:""}
  <button onclick="toggleBm('${q.id}')" class="${DB.bm[q.id]?"on":""}">⭐</button></div>
  <main>
  <div>${gtag}${trap}<span class="tag" style="background:var(--card2);color:var(--sub)">${esc(catName(q.category))}</span>
  <button class="lk" style="margin-left:8px" onclick="speakQuestion(curQ())">🔊 ${t('speak')}</button>
  ${micSupported?`<button class="lk" style="margin-left:6px" onclick="startListening()">${micLabel} ${curLang==="ja"?"話して答える":"Speak"}</button>`:""}
  </div>
  ${_voiceNote?`<div class="voice-note">${esc(_voiceNote)}</div>`:""}
  ${_listenState!=="idle"?`<div class="listen-bar ${_listenState}">${
    _listenState==="listening" ? (curLang==="ja"?"🎙 聞いています… 番号や選択肢を話してください":"🎙 Listening… say a number or choice")
    : _listenState==="processing" ? (curLang==="ja"?"処理中…":"Processing…")
    : esc(_listenText|| (curLang==="ja"?"認識エラー":"Error"))
  }${_listenText && _listenState!=="listening"?` <span class="lt">${esc(_listenText)}</span>`:""}</div>`:""}
  <div class="qq">${esc(tt(q.question))}</div>`;
  if(Z.picked===null){
    choices.forEach((c,i)=>{
      h+=`<button class="ch" onclick="pick(${i})"><b>${String.fromCharCode(65+i)}</b>${esc(c)}</button>`;
    });
  }else{
    choices.forEach((c,i)=>{
      let cls="ch disabled";
      if(i===q.answer) cls+=" right";
      else if(i===Z.picked) cls+=" wrong";
      h+=`<div class="${cls}"><b>${String.fromCharCode(65+i)}</b>${esc(c)}</div>`;
    });
    const ok=Z.picked===q.answer;
    h+=`<div class="verdict ${ok?"ok":"ng"}">${ok?"✅ "+t("correct"):"❌ "+t("wrong")}</div>
    <div class="panel">
      <h3>${t("detail")}</h3>
      ${q.general?"":`<dl>
        <dt>${t("heritage")}</dt><dd>${esc(tt(q.heritageName))}</dd>
        <dt>${t("country")}</dt><dd>${esc(cnm(q.country))}</dd>
        <dt>${t("year")}</dt><dd>${q.year}</dd>
        <dt>${t("type")}</dt><dd>${t("typeNames."+q.type)||q.type}</dd>
        <dt>${t("criteria")}</dt><dd>${q.criteria||"—"}</dd>
      </dl>`}
      <div class="pt">
        <div class="dh">${t("history")}</div>
        ${esc(tt(q.explanation))}
        ${q.isTrap?`<div class="tip">⚠️ ${t("trapNote")}: ${esc(tt(q.tip))}</div>`:""}
        ${critMeaning(q.criteria)}
        ${tt(q.ng)?`<div class="dh">${t("ngReason")}</div>${esc(tt(q.ng))}`:""}
        ${tt(q.tip)&&!q.isTrap?`<div class="dh">${t("tip")}</div>${esc(tt(q.tip))}`:""}
      </div>
    </div>
    <div class="row">
      <button class="btn primary" onclick="advance()">${Z.i+1>=Z.list.length?t("finish"):t("next")}</button>
      <button class="btn ghost" onclick="speakExplanation(curQ())">🔊 ${t("detail")}</button>
      <button class="btn share" onclick="shareCurrentQ()">📤 ${t("share")}</button>
      <button class="btn ghost" onclick="toggleBm('${q.id}')">${DB.bm[q.id]?"★":"☆"} ${t("bookmark")}</button>
    </div>`;
  }
  h+=`</main>`;
  // Auto-read unanswered question
  if(Z.picked===null && DB.set.voice && DB.set.voiceAuto && Z.spoken!==Z.i){
    Z.spoken=Z.i;
    setTimeout(()=>{ if(st.screen==="quiz"&&st.quiz===Z&&Z.i===Z.list.indexOf(q)) speakQuestion(q); }, 280);
  }
  return h;
}

function pick(i){
  const Z=st.quiz; if(!Z||Z.picked!==null) return;
  Z.picked=i;
  const q=Z.list[Z.i];
  const ok=i===q.answer;
  if(ok) playOK(); else playNG();
  // progress
  if(!DB.prog[q.id]) DB.prog[q.id]={a:0,c:0,l:0};
  DB.prog[q.id].a++;
  if(ok){ DB.prog[q.id].c++; DB.prog[q.id].l=1; } else DB.prog[q.id].l=0;
  const td=tdy(); td.n++; if(ok) td.c++;
  Z.log.push({q,ok,sel:choicesOf(q)[i],ans:choicesOf(q)[q.answer]});
  save();
  render();
}
function advance(){
  stopSpeak();
  stopListening();
  _voiceNote = "";
  const Z=st.quiz;
  if(Z.i+1>=Z.list.length){
    st.screen="result";
  }else{
    Z.i++; Z.picked=null; const mm=document.querySelector("main"); if(mm) mm.scrollTop=0;
  }
  render();
}
function toggleBm(id){
  if(DB.bm[id]) delete DB.bm[id]; else DB.bm[id]=1;
  save(); render();
}

function result(){
  const Z=st.quiz;
  const ok=Z.log.filter(x=>x.ok).length;
  const total=Z.mock? Z.list.length : Z.log.length;
  const rate=total?Math.round(ok/total*100):0;
  const verdict=Z.mock? `<div class="verdict ${rate>=70?"ok":"ng"}" style="margin-top:10px">${Z.timeUp?"⏱ "+t("timeUp")+" · ":""}${rate>=70?"🎉 "+t("passed"):t("failed")}</div>` : "";
  let h=`<div class="sb"><button onclick="go('home')">← ${t("home")}</button><div class="st">${t("resultTitle")}</div><span></span></div>
  <main>
  <div class="card" style="text-align:center">
    <div class="bigscore">${ok} / ${total}</div>
    <div style="font-size:18px;margin-bottom:8px">${t("rate")}: ${rate}%</div>
    <div class="pb" style="max-width:240px;margin:12px auto"><i style="width:${rate}%"></i></div>${verdict}
  </div>
  <div class="row" style="justify-content:center">
    <button class="btn primary" onclick="${Z.mock?"startMock()":"startQuiz()"}">${t("again")}</button>
    <button class="btn share" onclick="shareProgress()">📤 ${t("share")}</button>
    <button class="btn ghost" onclick="go('home')">${t("home")}</button>
  </div>
  <div class="card" style="margin-top:16px"><b>${t("review")}</b>
  <div style="margin-top:10px">`;
  Z.log.forEach((x,i)=>{
    h+=`<div class="li"><b>${i+1}. ${esc(ell(tt(x.q.question),60))}</b>
    <small style="color:${x.ok? "var(--ok)":"var(--ng)"}">${x.ok?"○":"×"} ${esc(x.sel)}${x.ok?"":" → "+esc(x.ans||"")}</small></div>`;
  });
  if(Z.mock && Z.log.length<Z.list.length) h+=`<div class="li"><small style="color:var(--sub)">${t("unans")}: ${Z.list.length-Z.log.length}</small></div>`;
  h+=`</div></div></main>`;
  return h;
}

/* Flashcards */
function flash(){
  if(!st.fl){
    const list=shuffle(HL.filter(h=>gradeIn(h.grade)));
    st.fl={list, i:0, flip:false};
  }
  const F=st.fl;
  if(!F.list.length) return `<main><p>${t("noData")}</p></main>`;
  const h=F.list[F.i];
  let card;
  if(!F.flip){
    card=`<div class="fc" onclick="st.fl.flip=true;render()">
      <div class="name">${esc(tt(h.name))}</div>
      <div class="meta">${t("flashFlip")}</div>
    </div>`;
  }else{
    card=`<div class="fc flip" onclick="st.fl.flip=false;render()">
      <div class="name">${esc(tt(h.name))}</div>
      <div class="meta">${esc(cnm(h.country))} · ${h.year} · ${t("typeNames."+h.type)||h.type}</div>
      <div class="meta" style="margin-top:8px">${h.criteria||""}</div>
      <div style="margin-top:12px;font-size:13px;color:var(--sub);max-width:90%">${esc(ell(tt(h.explain),120))}</div>
    </div>`;
  }
  return `<div class="sb"><button onclick="go('home')">←</button><div class="st">${F.i+1}/${F.list.length}</div><span></span></div>
  <main>${card}
  <div class="sw">
    <button class="btn ghost" onclick="fcMove(-1)">← ${t("prev")}</button>
    <button class="btn primary" onclick="fcMove(1)">${t("nextCard")} →</button>
  </div></main>`;
}
function fcMove(d){
  const F=st.fl; if(!F) return;
  F.i=(F.i+d+F.list.length)%F.list.length;
  F.flip=false;
  render();
}

/* Browse */
function browseList(){
  const kw=(st.bq||"").trim().toLowerCase();
  const list=HL.filter(h=>gradeIn(h.grade) &&
    (!kw || (h.name.ja+" "+h.name.en+" "+h.country.ja+" "+h.country.en).toLowerCase().includes(kw)));
  return `<div class="pl" style="margin-bottom:6px">${list.length}${t("items")}</div>`+list.map(x=>`<div class="li"><b>${esc(tt(x.name))}</b>
    <small>${esc(cnm(x.country))} · ${x.year} · ${t("typeNames."+x.type)||x.type} · ${x.criteria||""}</small></div>`).join("");
}
function updBrowse(){ const el=document.getElementById("bl"); if(el) el.innerHTML=browseList(); }
function browse(){
  return `<div class="sb"><button onclick="go('home')">←</button><div class="st">${t("menu.browse")}</div><span></span></div>
  <main><input type="search" value="${esc(st.bq||"")}" placeholder="${t("searchPh")}" oninput="st.bq=this.value;updBrowse()" style="width:100%;background:var(--card);border:1px solid var(--line);border-radius:12px;padding:10px 12px;margin-bottom:10px;cursor:text">
  <div class="card" id="bl">${browseList()}</div></main>`;
}

/* Report */
function report(){
  const byG={}, byC={}, byR={}, wrong={};
  Q.forEach(q=>{
    const p=DB.prog[q.id];
    if(!p) return;
    const g=q.grade, c=q.category, r=q.region||"other";
    if(!byG[g]) byG[g]={a:0,c:0}; byG[g].a+=p.a; byG[g].c+=p.c;
    if(!byC[c]) byC[c]={a:0,c:0}; byC[c].a+=p.a; byC[c].c+=p.c;
    if(!byR[r]) byR[r]={a:0,c:0}; byR[r].a+=p.a; byR[r].c+=p.c;
    if(p.l===0 && !q.general){ const n=tt(q.heritageName); wrong[n]=(wrong[n]||0)+1; }
  });
  const wl=Object.entries(wrong).sort((a,b)=>b[1]-a[1]).slice(0,5);
  function pbar(lab,o){
    const r=o&&o.a?Math.round(o.c/o.a*100):0;
    return `<div class="pbar"><div class="lab"><span>${esc(lab)}</span><span>${o&&o.a?r+"% ("+o.c+"/"+o.a+")":t("noData")}</span></div>
    <div class="bar"><i style="width:${r}%"></i></div></div>`;
  }
  let h=`<div class="sb"><button onclick="go('home')">←</button><div class="st">${t("menu.report")}</div><span></span></div>
  <main>
  <div class="card"><b>${t("reportGrade")}</b>${Object.keys(byG).map(k=>pbar(t("grades."+k),byG[k])).join("")||"<p>"+t("noData")+"</p>"}</div>
  <div class="card"><b>${t("reportCat")}</b>${Object.keys(byC).map(k=>pbar(catName(k),byC[k])).join("")||""}</div>
  <div class="card"><b>${t("reportRegion")}</b>${Object.keys(byR).map(k=>pbar(regName(k),byR[k])).join("")||""}</div>
  <div class="card"><b>${t("topWrong")}</b><div style="margin-top:8px">${wl.length?wl.map((x,i)=>(i+1)+". "+esc(x[0])+" ("+x[1]+")").join("<br>"):t("noData")}</div></div>
  <div class="row"><button class="btn primary" onclick="startSmart()">🎯 ${t("smart")}</button>
  <button class="btn share" onclick="shareProgress()">📤 ${t("share")}</button></div>
  </main>`;
  return h;
}

/* Mock */
function mock(){
  return `<div class="sb"><button onclick="go('home')">←</button><div class="st">${t("menu.mock")}</div><span></span></div>
  <main class="card">
  <p style="margin-bottom:14px">${t("mockDesc")}</p>
  <p style="margin-bottom:14px;color:var(--sub);font-size:13px">${t("grade")}: <b style="color:var(--tx)">${DB.set.grade==="all"?t("all"):t("grades."+DB.set.grade)}</b> · ${mockSpec().n}${t("mockInfo")} ${Math.round(mockSpec().sec/60)}${t("min")}</p>
  <button class="go" onclick="startMock()" ${mockSpec().n?"":"disabled"}>📝 ${t("mockStart")}</button>
  </main>`;
}
function mockSpec(){
  const g=DB.set.grade;
  const n = g==="4"?20 : (g==="all"||g==="3")?30 : 40;
  const cnt = Math.min(n, pool().length);
  return {n:cnt, sec:cnt*45};
}
function fmtT(ms){ ms=Math.max(0,ms); const s=Math.ceil(ms/1000); return Math.floor(s/60)+":"+String(s%60).padStart(2,"0"); }
function startMock(){
  const sp=mockSpec();
  if(!sp.n){ toast(t("noData")); return; }
  const list=prepList(shuffle(pool()).slice(0,sp.n));
  st.quiz={list,i:0,picked:null,log:[],mock:true,deadline:Date.now()+sp.sec*1000};
  st.screen="quiz";
  bgmStart();
  render();
}
setInterval(()=>{
  const Z=st.quiz;
  if(st.screen!=="quiz"||!Z||!Z.deadline) return;
  const left=Z.deadline-Date.now();
  const el=document.getElementById("tmr");
  if(left<=0){ stopSpeak(); Z.timeUp=true; st.screen="result"; render(); }
  else if(el) el.textContent=fmtT(left);
},500);

/* Guide */
function guide(){
  const tips = {
    ja:`<h3>級ごとのポイント</h3>
    <p><b>4級</b>：日本の遺産と世界の超有名遺産が中心。登録年・種別の基本を固める。</p>
    <p><b>3級</b>：日本の遺産を中心にやや細かい知識。複合遺産・負の遺産の概念。</p>
    <p><b>2級</b>：世界の主要遺産。登録基準の意味、危機遺産、拡張登録など。</p>
    <p><b>準1級・1級</b>：ひっかけが増加。構成資産の細部、登録基準の組み合わせ、条約の歴史的背景。</p>
    <h3>頻出ひっかけ</h3>
    <ul style="padding-left:18px;margin:8px 0">
    <li>富士山は文化遺産（自然ではない）</li>
    <li>マチュピチュ・カッパドキア・パムッカレは複合遺産</li>
    <li>原爆ドーム・アウシュヴィッツ・ゴレ島・ロベン島は負の遺産（(vi)）</li>
    <li>軍艦島は単独ではなく明治産業革命遺産の一部</li>
    <li>屋久島＋白神山地＝1993年日本初の自然遺産</li>
    </ul>`,
    en:`<h3>Tips by Level</h3>
    <p><b>Level 4</b>: Famous Japanese & world sites. Basics of year and type.</p>
    <p><b>Level 3</b>: More Japanese detail. Mixed sites & negative heritage concepts.</p>
    <p><b>Level 2</b>: Major world sites. Meaning of criteria, Danger List, extensions.</p>
    <p><b>Pre-1 / Level 1</b>: More traps. Component parts, criterion combinations, history of the Convention.</p>
    <h3>Classic Traps</h3>
    <ul style="padding-left:18px;margin:8px 0">
    <li>Fujisan is cultural (not natural)</li>
    <li>Machu Picchu, Cappadocia, Pamukkale are mixed</li>
    <li>Genbaku Dome, Auschwitz, Gorée, Robben Island = negative heritage (vi)</li>
    <li>Gunkanjima is a component of Meiji Industrial Sites, not a site by itself</li>
    <li>Yakushima + Shirakami-Sanchi = Japan’s first natural sites (1993)</li>
    </ul>`
  };
  return `<div class="sb"><button onclick="go('home')">←</button><div class="st">${t("guideTitle")}</div><span></span></div>
  <main class="card">${tips[curLang]||tips.en}</main>`;
}

/* Modal */
function modal(which){
  st.modal=which;
  render();
}
function modalHTML(){
  if(!st.modal) return "";
  let body="";
  if(st.modal==="set"){
    body=`<h4>${t("settings")}</h4>
    <div class="opt"><span>${t("lang")}</span>
      <select onchange="DB.set.lang=this.value;initLang();save();render()" style="max-width:170px">
        <option value="auto" ${DB.set.lang==="auto"?"selected":""}>${t("autoLang")}</option>
        <option value="ja" ${DB.set.lang==="ja"?"selected":""}>🇯🇵 日本語</option>
        <option value="en" ${DB.set.lang==="en"?"selected":""}>🇺🇸 English</option>
        <option value="fr" ${DB.set.lang==="fr"?"selected":""}>🇫🇷 Français</option>
        <option value="pt" ${DB.set.lang==="pt"?"selected":""}>🇧🇷 Português</option>
        <option value="es" ${DB.set.lang==="es"?"selected":""}>🇪🇸 Español</option>
        <option value="zh" ${DB.set.lang==="zh"?"selected":""}>🇨🇳 中文</option>
        <option value="ko" ${DB.set.lang==="ko"?"selected":""}>🇰🇷 한국어</option>
        <option value="de" ${DB.set.lang==="de"?"selected":""}>🇩🇪 Deutsch</option>
        <option value="it" ${DB.set.lang==="it"?"selected":""}>🇮🇹 Italiano</option>
        <option value="ar" ${DB.set.lang==="ar"?"selected":""}>🇸🇦 العربية</option>
        <option value="hi" ${DB.set.lang==="hi"?"selected":""}>🇮🇳 हिन्दी</option>
        <option value="ru" ${DB.set.lang==="ru"?"selected":""}>🇷🇺 Русский</option>
        <option value="th" ${DB.set.lang==="th"?"selected":""}>🇹🇭 ไทย</option>
        <option value="id" ${DB.set.lang==="id"?"selected":""}>🇮🇩 Indonesia</option>
        <option value="tr" ${DB.set.lang==="tr"?"selected":""}>🇹🇷 Türkçe</option>
      </select>
    </div>
    <div class="opt"><span>${t("bgm")}</span><button class="tg ${DB.set.bgm?"on":""}" onclick="DB.set.bgm=!DB.set.bgm;if(DB.set.bgm&&st.screen==="quiz")bgmStart();else bgmStop();save();render()">${DB.set.bgm?"ON":"OFF"}</button></div>
    <div class="opt"><span>${t("se")}</span><button class="tg ${DB.set.se?"on":""}" onclick="DB.set.se=!DB.set.se;save();render()">${DB.set.se?"ON":"OFF"}</button></div>
    <div class="opt"><span>${t("voice")}</span><button class="tg ${DB.set.voice?"on":""}" onclick="DB.set.voice=!DB.set.voice;if(!DB.set.voice)stopSpeak();save();render()">${DB.set.voice?"ON":"OFF"}</button></div>
    <div class="opt"><span>${t("voiceAuto")}</span><button class="tg ${DB.set.voiceAuto?"on":""}" onclick="DB.set.voiceAuto=!DB.set.voiceAuto;save();render()">${DB.set.voiceAuto?"ON":"OFF"}</button></div>
    <div class="opt"><span>${t("volume")}</span><input type="range" min="0" max="1" step="0.05" value="${DB.set.vol}" oninput="DB.set.vol=+this.value;if(master)master.gain.value=DB.set.vol;save()" style="width:120px"></div>
    <div class="opt"><span>${t("goalSet")}</span><input type="number" min="5" max="100" value="${DB.set.goal}" onchange="DB.set.goal=+this.value||20;save();render()" style="width:70px;background:var(--card2);border:1px solid var(--line);border-radius:8px;padding:6px;color:var(--tx)"></div>
    <div class="opt"><span>${t("trapMode")}</span><button class="tg ${DB.set.trapOnly?"on":""}" onclick="DB.set.trapOnly=!DB.set.trapOnly;save();render()">${DB.set.trapOnly?"ON":"OFF"}</button></div>
    <button class="btn primary" style="width:100%;margin-top:12px" onclick="modal(null)">${t("close")}</button>`;
  }else if(st.modal==="field"){
    body=`<h4>${t("field")}</h4>`;
    ["all","jp","world","cultural","natural"].forEach(k=>{
      body+=`<button class="li" onclick="DB.set.field='${k}';save();modal(null)">${t("fields."+k)}</button>`;
    });
  }
  return `<div class="sheet" onclick="if(event.target===this)modal(null)"><div>${body}</div></div>`;
}

/* Navigation */
function go(s){
  stopSpeak();
  stopListening();
  _voiceNote = "";
  st.screen=s;
  st.quiz=null; st.fl=null; st.modal=null;
  if(s!=="quiz"&&s!=="flash") bgmStop();
  render();
}

/* Render */
function render(){
  const app=$("#app");
  let html="";
  if(st.screen==="home"){
    html=`<div class="hd">
      <select aria-label="grade" onchange="setGrade(this.value)">
        <option value="all" ${DB.set.grade==="all"?"selected":""}>${t("all")}</option>
        <option value="4" ${DB.set.grade==="4"?"selected":""}>${t("grades.4")}</option>
        <option value="3" ${DB.set.grade==="3"?"selected":""}>${t("grades.3")}</option>
        <option value="2" ${DB.set.grade==="2"?"selected":""}>${t("grades.2")}</option>
        <option value="p1" ${DB.set.grade==="p1"?"selected":""}>${t("grades.p1")}</option>
        <option value="1" ${DB.set.grade==="1"?"selected":""}>${t("grades.1")}</option>
      </select>
      <div class="tt">${t("title")}</div>
      <span style="display:flex;gap:6px">
        <select class="lang-sel" onchange="DB.set.lang=this.value;initLang();save();render()" title="Language" aria-label="Language">
          <option value="ja" ${curLang==="ja"?"selected":""}>JA</option>
          <option value="en" ${curLang==="en"?"selected":""}>EN</option>
          <option value="fr" ${curLang==="fr"?"selected":""}>FR</option>
          <option value="pt" ${curLang==="pt"?"selected":""}>PT</option>
          <option value="es" ${curLang==="es"?"selected":""}>ES</option>
          <option value="zh" ${curLang==="zh"?"selected":""}>ZH</option>
          <option value="ko" ${curLang==="ko"?"selected":""}>KO</option>
          <option value="de" ${curLang==="de"?"selected":""}>DE</option>
          <option value="it" ${curLang==="it"?"selected":""}>IT</option>
          <option value="ar" ${curLang==="ar"?"selected":""}>AR</option>
          <option value="hi" ${curLang==="hi"?"selected":""}>HI</option>
          <option value="ru" ${curLang==="ru"?"selected":""}>RU</option>
          <option value="th" ${curLang==="th"?"selected":""}>TH</option>
          <option value="id" ${curLang==="id"?"selected":""}>ID</option>
          <option value="tr" ${curLang==="tr"?"selected":""}>TR</option>
        </select>
        <button class="ic" onclick="modal('set')" aria-label="Settings">⚙️</button>
      </span>
    </div><main>${home()}</main>`;
  }else if(st.screen==="quiz") html=quiz();
  else if(st.screen==="result") html=result();
  else if(st.screen==="flash") html=flash();
  else if(st.screen==="browse") html=browse();
  else if(st.screen==="report") html=report();
  else if(st.screen==="mock") html=mock();
  else if(st.screen==="guide") html=guide();
  else if(st.screen==="import") html=importScr();

  html+=modalHTML();
  if(st.toast) html+=`<div class="toast">${esc(st.toast)}</div>`;
  app.innerHTML=html;
}

function cycleLang(){
  const order=["ja","en","fr","pt","es","zh","ko","de","it","ar","hi","ru","th","id","tr"];
  const i=order.indexOf(curLang);
  DB.set.lang=order[(i+1)%order.length];
  initLang();
  save();
  render();
}

/* Keyboard */
document.addEventListener("keydown",e=>{
  if(e.target.tagName==="INPUT"||e.target.tagName==="SELECT"||e.target.tagName==="TEXTAREA") return;
  if(e.key==="Escape"){ if(st.modal) modal(null); else if(st.screen!=="home") go("home"); return; }
  if(st.modal) return;
  if(st.screen==="quiz"&&st.quiz){
    const Z=st.quiz;
    if(Z.picked===null){
      const i="1234".indexOf(e.key);
      const j="abcd".indexOf(String(e.key).toLowerCase());
      if(i>=0) pick(i); else if(j>=0) pick(j);
    }else if(e.key==="Enter"||e.key===" "||e.key==="ArrowRight"){ e.preventDefault(); advance(); }
    else if(String(e.key).toLowerCase()==="b") toggleBm(Z.list[Z.i].id);
  }else if(st.screen==="flash"&&st.fl){
    if(e.key==="ArrowRight") fcMove(1);
    else if(e.key==="ArrowLeft") fcMove(-1);
    else if(e.key===" "||e.key==="Enter"){ e.preventDefault(); st.fl.flip=!st.fl.flip; render(); }
  }
});

/* Touch swipe for flash / next */
let tx0=0,ty0=0;
document.addEventListener("touchstart",e=>{const t=e.changedTouches[0];tx0=t.clientX;ty0=t.clientY;},{passive:true});
document.addEventListener("touchend",e=>{
  if(st.modal) return;
  const t=e.changedTouches[0], dx=t.clientX-tx0, dy=t.clientY-ty0;
  if(Math.abs(dx)<70||Math.abs(dy)>50) return;
  if(st.screen==="flash"&&st.fl) fcMove(dx<0?1:-1);
  else if(st.screen==="quiz"&&st.quiz&&st.quiz.picked!==null&&dx<0) advance();
},{passive:true});

/* Study time */
setInterval(()=>{
  if(document.hidden) return;
  if(st.screen==="quiz"||st.screen==="flash"){ const t=tdy(); t.s=(t.s||0)+10; save(); }
},10000);

/* First interaction → audio unlock */
document.addEventListener("click",function once(){ ac(); document.removeEventListener("click",once); },{once:true});

render();
