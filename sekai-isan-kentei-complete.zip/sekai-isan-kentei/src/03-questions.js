/* Generate questions from heritages */
const Q = [];
const HL = []; // heritage list for flash/browse

function hash36(str){ let h=5381; for(let i=0;i<str.length;i++){ h=((h<<5)+h+str.charCodeAt(i))>>>0; } return h.toString(36); }
function addQ(obj){ Q.push(obj); }
function pickN(arr,n){ const b=arr.slice(); for(let i=b.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[b[i],b[j]]=[b[j],b[i]];} return b.slice(0,n); }

const REGION_OF = {};
[["日本",["日本"]],
 ["アジア",["中国","インド","カンボジア","インドネシア","ベトナム","ラオス","タイ","ミャンマー"]],
 ["中東",["ヨルダン","トルコ","イラン"]],
 ["ヨーロッパ",["フランス","イギリス","チェコ","イタリア","ギリシャ","スペイン","ポーランド","ヴァチカン","オーストリア","ハンガリー","ポルトガル"]],
 ["アフリカ",["ジンバブエ","タンザニア","エジプト","南アフリカ","セネガル","ザンビア・ジンバブエ","マリ"]],
 ["南北アメリカ",["アメリカ合衆国","ペルー","エクアドル","チリ","アルゼンチン","メキシコ","ブラジル","グアテマラ","ホンジュラス"]],
 ["オセアニア",["オーストラリア"]]
].forEach(([r,cs])=>cs.forEach(c=>REGION_OF[c]=r));
function regionOf(c){ return REGION_OF[c]||"その他"; }

// De-duplicate heritages by Japanese name (keep the richest entry)
const HUNIQ = (()=>{
  const m = new Map();
  HERITAGES.forEach(h=>{
    const o = m.get(h.ja);
    if(!o){ m.set(h.ja, Object.assign({}, h)); return; }
    const keep = (h.ej||"").length > (o.ej||"").length ? Object.assign({}, h) : o;
    keep.trap = !!(h.trap || o.trap);
    m.set(h.ja, keep);
  });
  const m2 = new Map();
  [...m.values()].forEach(h=>{
    const k=h.en.toLowerCase(), o=m2.get(k);
    if(!o){ m2.set(k,h); return; }
    const keep=(h.ej||"").length>(o.ej||"").length?h:o; keep.trap=!!(h.trap||o.trap); m2.set(k,keep);
  });
  return [...m2.values()];
})();

// Pools for distractors
const COUNTRY_POOL = (()=>{ const m=new Map(); HUNIQ.forEach(h=>{ if(!m.has(h.cja)) m.set(h.cja,h.cen); }); return [...m].map(([ja,en])=>({ja,en})); })();
COUNTRY_POOL.forEach(c=>CEN[c.ja]=c.en);
const CRIT_POOL = [...new Set(HUNIQ.map(h=>h.crit).filter(Boolean))];

HUNIQ.forEach(h=>{
  const region = regionOf(h.cja);
  HL.push({
    id: h.g + "-" + h.ja,
    grade: h.g,
    name: {ja:h.ja, en:h.en},
    country: {ja:h.cja, en:h.cen},
    year: h.y,
    type: h.type,
    criteria: h.crit,
    explain: {ja:h.ej, en:h.ee},
    region
  });
  const hb = h.g + "_" + hash36(h.ja);
  const base = {
    grade: h.g, region,
    heritageName: {ja:h.ja, en:h.en},
    country: {ja:h.cja, en:h.cen},
    year: h.y, criteria: h.crit, type: h.type
  };
  const typeEn = h.type==="文化遺産"?"Cultural":h.type==="自然遺産"?"Natural":"Mixed";

  // 1. Which heritage? (description → name)
  const pairs = [];
  const seenN = new Set([h.ja]);
  h.wj.forEach((w,i)=>{ if(!seenN.has(w)){ seenN.add(w); pairs.push([w,(h.we&&h.we[i])||w]); } });
  if(pairs.length<3){
    pickN(HUNIQ.filter(o=>o.g===h.g && o.type===h.type && !seenN.has(o.ja)),6).forEach(o=>{
      if(pairs.length<3 && !seenN.has(o.ja)){ seenN.add(o.ja); pairs.push([o.ja,o.en]); }
    });
  }
  const pp = pairs.slice(0,3);
  addQ(Object.assign({}, base, {
    id: hb+"_w",
    category: "該当遺産",
    question: {
      ja: h.ej.split("。")[0] + "。これに該当する世界遺産はどれか。",
      en: (h.ee.split(".")[0] || h.ee) + ". Which World Heritage site is this?"
    },
    choices: { ja:[h.ja, ...pp.map(x=>x[0])], en:[h.en, ...pp.map(x=>x[1])] },
    answer: 0,
    explanation: {ja:h.ej, en:h.ee},
    ng: {ja:"他の選択肢は別の遺産です。", en:"The other options are different sites."},
    tip: {ja: h.trap ? "ひっかけ要素あり。名称や種別を正確に。" : "特徴をしっかり覚えよう。", en: h.trap ? "Contains a trap element. Check name and type carefully." : "Memorize the key features."},
    isTrap: !!h.trap
  }));

  // 2. Year (distinct distractors near the correct year)
  const yc = [-1,1,-2,2,-3,3,-4,4,-5,5,-6,6].map(d=>h.y+d).filter(y=>y>=1978 && y<=2025 && y!==h.y);
  const yw = pickN(yc,3);
  addQ(Object.assign({}, base, {
    id: hb+"_y",
    category: "登録年",
    question: {
      ja: `「${h.ja}」が世界遺産に登録された年はどれか。`,
      en: `In which year was “${h.en}” inscribed on the World Heritage List?`
    },
    choices: { ja:[String(h.y), ...yw.map(String)], en:[String(h.y), ...yw.map(String)] },
    answer: 0,
    explanation: {ja:`${h.ja}は${h.y}年に登録されました。${h.ej}`, en:`${h.en} was inscribed in ${h.y}. ${h.ee}`},
    ng: {ja:"登録年を正確に覚えましょう。近い年の遺産と混同しやすいです。", en:"Remember the exact year. Easy to confuse with nearby inscriptions."},
    tip: {ja:"1978年（第1回）や日本の初登録年（1993）は特に重要。", en:"1978 (first session) and Japan’s first inscriptions (1993) are especially important."},
    isTrap: Math.abs(h.y-1978)<3 || Math.abs(h.y-1993)<2
  }));

  // 3. Type (文化/自然/複合) — fixed option order
  const typeOptsJa = ["文化遺産","自然遺産","複合遺産"];
  const typeOptsEn = ["Cultural","Natural","Mixed"];
  if(typeOptsJa.indexOf(h.type)>=0){
    addQ(Object.assign({}, base, {
      id: hb+"_t",
      category: "種別",
      question: {
        ja: `「${h.ja}」の種別として正しいものはどれか。`,
        en: `What is the correct type of “${h.en}”?`
      },
      choices: { ja:typeOptsJa, en:typeOptsEn },
      answer: typeOptsJa.indexOf(h.type),
      fixedOrder: true,
      explanation: {ja:`${h.ja}は${h.type}です。${h.ej}`, en:`${h.en} is a ${typeEn} site. ${h.ee}`},
      ng: {ja:"文化・自然・複合の区別は最重要ポイント。富士山やマチュピチュなどで頻出。", en:"Cultural / Natural / Mixed distinction is critical. Classic traps: Fujisan, Machu Picchu."},
      tip: {ja:h.type==="複合遺産"?"複合遺産は数が少ないので要暗記。":"種別を必ずセットで覚える。", en:h.type==="複合遺産"?"Mixed sites are few — memorize them.":"Always learn the type together with the name."},
      isTrap: h.type==="複合遺産" || h.ja.includes("富士") || !!h.trap
    }));
  }

  // 4. Country (distinct distractors, same region preferred)
  const others = COUNTRY_POOL.filter(c=>c.ja!==h.cja && !h.cja.includes(c.ja) && !c.ja.includes(h.cja));
  const sameR = pickN(others.filter(c=>regionOf(c.ja)===region),3);
  const rest = pickN(others.filter(c=>!sameR.includes(c)),3-sameR.length);
  const cw = sameR.concat(rest).slice(0,3);
  addQ(Object.assign({}, base, {
    id: hb+"_c",
    category: "所在国",
    question: {
      ja: `「${h.ja}」が所在する国はどれか。`,
      en: `In which country is “${h.en}” located?`
    },
    choices: { ja:[h.cja, ...cw.map(c=>c.ja)], en:[h.cen, ...cw.map(c=>c.en)] },
    cc: [h.cja, ...cw.map(c=>c.ja)],
    answer: 0,
    explanation: {ja:`${h.ja}は${h.cja}に所在します。${h.ej}`, en:`${h.en} is located in ${h.cen}. ${h.ee}`},
    ng: {ja:"国名と遺産名をセットで覚える。", en:"Learn country and site name together."},
    tip: {ja:"同じ国の複数遺産をまとめて覚えると効率的。", en:"Group sites by country for efficiency."},
    isTrap: false
  }));

  // 5. Criteria (higher grades or trap ones)
  if((h.g!=="4" || h.trap) && h.crit){
    const sim = CRIT_POOL.filter(c=>c!==h.crit);
    const cr = pickN(sim,3);
    addQ(Object.assign({}, base, {
      id: hb+"_k",
      category: "登録基準",
      question: {
        ja: `「${h.ja}」に適用されている登録基準として最も適切なものはどれか。`,
        en: `Which criterion (or set) is applied to “${h.en}”?`
      },
      choices: { ja:[h.crit, ...cr], en:[h.crit, ...cr] },
      answer: 0,
      explanation: {ja:`登録基準は ${h.crit} です。${h.ej}`, en:`Criteria: ${h.crit}. ${h.ee}`},
      ng: {ja:"登録基準の番号と意味を対応させて覚える。", en:"Link criterion numbers to their meanings."},
      tip: {ja:"(vi)単独は負の遺産に多い。(i)単独は傑作に多い。", en:"(vi) alone often negative heritage. (i) alone often masterpieces."},
      isTrap: h.crit==="(vi)" || h.crit==="(i)"
    }));
  }
});


/* ---- Additional question types (more questions per level) ---- */
function distract(h,fn){
  const pool=HUNIQ.filter(o=>o.ja!==h.ja && fn(o));
  const same=pickN(pool.filter(o=>o.g===h.g),3);
  return same.concat(pickN(pool.filter(o=>!same.includes(o)),3-same.length)).slice(0,3);
}
HUNIQ.forEach(h=>{
  const region=regionOf(h.cja), hb=h.g+"_"+hash36(h.ja);
  const base={grade:h.g,region,heritageName:{ja:h.ja,en:h.en},country:{ja:h.cja,en:h.cen},year:h.y,criteria:h.crit,type:h.type};
  const mk=(id,cat,qj,qe,ds,trap,expj,expe,ng)=>{
    if(ds.length<3) return;
    addQ(Object.assign({},base,{id:hb+"_"+id,category:cat,question:{ja:qj,en:qe},
      choices:{ja:[h.ja,...ds.map(o=>o.ja)],en:[h.en,...ds.map(o=>o.en)]},answer:0,
      explanation:{ja:expj,en:expe},ng:{ja:ng,en:"The other options are different sites."},
      tip:{ja:"遺産名と国・年・種別をセットで覚えよう。",en:"Learn each name together with its country, year and type."},isTrap:!!trap}));
  };
  mk("s","所在遺産",`次のうち「${h.cja}」に所在する世界遺産はどれか。`,`Which of the following World Heritage sites is located in ${h.cen}?`,
     distract(h,o=>o.cja!==h.cja&&!h.cja.includes(o.cja)&&!o.cja.includes(h.cja)),false,
     `${h.ja}は${h.cja}にあります。${h.ej}`,`${h.en} is in ${h.cen}. ${h.ee}`,"他の選択肢は別の国の遺産です。");
  const tn={"文化遺産":["文化遺産","Cultural"],"自然遺産":["自然遺産","Natural"],"複合遺産":["複合遺産","Mixed"]}[h.type];
  if(tn) mk("p","種別選択",`次のうち、${tn[0]}として登録されているものはどれか。`,`Which of the following is inscribed as a ${tn[1]} site?`,
     distract(h,o=>o.type!==h.type),h.type==="複合遺産"||h.type==="自然遺産"&&h.ja.includes("富士"),
     `${h.ja}は${h.type}です。${h.ej}`,`${h.en} is ${tn[1]}. ${h.ee}`,"他の選択肢は種別が異なります。");
  if(h.y<=2019) mk("o","登録順","次のうち、最も早く世界遺産に登録されたものはどれか。","Which of the following was inscribed on the World Heritage List earliest?",
     distract(h,o=>o.y>h.y+1),false,`${h.ja}は${h.y}年の登録で、選択肢の中で最も早い登録です。`,`${h.en} (${h.y}) is the earliest of the options.`,"他の選択肢はより後に登録されました。");
  mk("r","年→遺産",`${h.y}年に世界遺産に登録されたものはどれか。`,`Which site was inscribed on the World Heritage List in ${h.y}?`,
     distract(h,o=>o.y!==h.y),false,`${h.ja}は${h.y}年に登録されました。${h.ej}`,`${h.en} was inscribed in ${h.y}. ${h.ee}`,"他の選択肢は別の年の登録です。");
});

const GEN_Q=[
["2","制度・知識","世界遺産条約が採択された年はどれか。","In which year was the World Heritage Convention adopted?",["1972年","1975年","1978年","1992年"],["1972","1975","1978","1992"],0,"1972年のユネスコ総会で採択され、1975年に発効しました。","Adopted at the 1972 UNESCO General Conference; in force from 1975.",0],
["p1","制度・知識","日本が世界遺産条約を締結した年はどれか。","In which year did Japan accede to the World Heritage Convention?",["1972年","1985年","1992年","1998年"],["1972","1985","1992","1998"],2,"日本の締結は1992年で、1993年に最初の4件が登録されました。","Japan acceded in 1992; its first four sites were inscribed in 1993.",0],
["3","制度・知識","世界遺産リストへの登録を最終的に決定する機関はどれか。","Which body makes the final decision on inscription?",["世界遺産委員会","ICOMOS","IUCN","ユネスコ事務局"],["World Heritage Committee","ICOMOS","IUCN","UNESCO Secretariat"],0,"ICOMOS・IUCNは諮問機関で、最終決定は世界遺産委員会が行います。","ICOMOS and IUCN advise; the World Heritage Committee decides.",1],
["p1","制度・知識","自然遺産の専門的評価を行う諮問機関はどれか。","Which advisory body evaluates natural sites?",["IUCN","ICOMOS","ICCROM","WWF"],["IUCN","ICOMOS","ICCROM","WWF"],0,"自然遺産はIUCN（国際自然保護連合）、文化遺産はICOMOS（国際記念物遺跡会議）が評価します。","IUCN evaluates natural sites; ICOMOS evaluates cultural sites.",1],
["2","制度・知識","文化遺産の専門的評価を行う諮問機関はどれか。","Which advisory body evaluates cultural sites?",["ICOMOS","IUCN","WHO","ICAO"],["ICOMOS","IUCN","WHO","ICAO"],0,"ICOMOS（国際記念物遺跡会議）が文化遺産を評価します。","ICOMOS evaluates cultural sites.",0],
["p1","制度・知識","世界遺産委員会の委員国の数はどれか。","How many States Parties sit on the World Heritage Committee?",["15","21","30","42"],["15","21","30","42"],1,"委員国は21か国で、任期は原則6年です。","21 States Parties, with terms of up to six years.",0],
["2","制度・知識","1978年に最初に登録された遺産に含まれるのはどれか。","Which of these was among the first sites inscribed in 1978?",["ガラパゴス諸島","姫路城","マチュ・ピチュ","アンコール"],["Galápagos Islands","Himeji Castle","Machu Picchu","Angkor"],0,"1978年の第1回登録（12件）にガラパゴス諸島が含まれます。","The Galápagos Islands were among the first 12 sites in 1978.",0],
["3","日本","1993年に日本で最初に登録された遺産に含まれないものはどれか。","Which was NOT among Japan's first sites inscribed in 1993?",["古都京都の文化財","法隆寺地域の仏教建造物群","姫路城","屋久島"],["Historic Monuments of Ancient Kyoto","Horyu-ji Area","Himeji Castle","Yakushima"],0,"古都京都の文化財は1994年の登録です。","Kyoto was inscribed in 1994.",1],
["3","日本","日本で複合遺産として登録されているものはどれか。","Which Japanese site is inscribed as a Mixed site?",["現在はない","富士山","屋久島","知床"],["None at present","Fujisan","Yakushima","Shiretoko"],0,"日本の複合遺産はありません。富士山は文化遺産、屋久島・知床は自然遺産です。","Japan has no Mixed site. Fujisan is cultural; Yakushima and Shiretoko are natural.",1],
["2","日本","日本の自然遺産の数はどれか。","How many natural sites does Japan have?",["5件","3件","4件","6件"],["5","3","4","6"],0,"屋久島・白神山地・知床・小笠原諸島・奄美大島ほかの5件です。","Yakushima, Shirakami-Sanchi, Shiretoko, Ogasawara, and Amami-Oshima & others.",0],
["p1","制度・知識","2021年に世界遺産リストから削除された英国の遺産はどれか。","Which UK site was delisted in 2021?",["リヴァプール海商都市","バース市街","エディンバラ旧市街・新市街","ロンドン塔"],["Liverpool Maritime Mercantile City","City of Bath","Old and New Towns of Edinburgh","Tower of London"],0,"再開発による価値の損失で削除されました。","Delisted over development that harmed its value.",1],
["1","制度・知識","2009年に世界遺産リストから削除されたドイツの遺産はどれか。","Which German site was delisted in 2009?",["ドレスデン・エルベ渓谷","ケルン大聖堂","ヴュルツブルクの司教館","アーヘン大聖堂"],["Dresden Elbe Valley","Cologne Cathedral","Würzburg Residence","Aachen Cathedral"],0,"橋の建設計画で景観が損なわれ削除されました。","Delisted after a bridge project damaged the landscape.",1],
["3","制度・知識","自然遺産のみに適用される登録基準はどれか。","Which criteria apply only to natural sites?",["(vii)〜(x)","(i)〜(vi)","(i)〜(iii)","(iv)〜(vi)"],["(vii)–(x)","(i)–(vi)","(i)–(iii)","(iv)–(vi)"],0,"(i)〜(vi)は文化、(vii)〜(x)は自然の基準です。","(i)–(vi) are cultural; (vii)–(x) are natural.",0],
["4","制度・知識","世界遺産事業を行う国連の専門機関はどれか。","Which UN agency runs the World Heritage programme?",["ユネスコ","ユニセフ","WHO","FAO"],["UNESCO","UNICEF","WHO","FAO"],0,"ユネスコ（国連教育科学文化機関）です。","UNESCO.",0],
["4","制度・知識","世界遺産の種類の組み合わせとして正しいものはどれか。","Which lists the three types of World Heritage?",["文化・自然・複合","文化・自然・無形","自然・複合・負","文化・無形・複合"],["Cultural, Natural, Mixed","Cultural, Natural, Intangible","Natural, Mixed, Negative","Cultural, Intangible, Mixed"],0,"無形文化遺産は別の条約の制度です。","Intangible heritage is a separate convention.",1],
["2","制度・知識","文化遺産にのみ求められる条件はどれか。","Which condition is required for cultural sites only?",["真正性","完全性","保護管理体制","顕著な普遍的価値"],["Authenticity","Integrity","Protection and management","Outstanding Universal Value"],0,"真正性は文化遺産、完全性は文化・自然の両方で求められます。","Authenticity applies to cultural sites; integrity applies to both.",1],
["3","制度・知識","世界遺産に推薦されるために、まず記載される必要があるリストはどれか。","Which list must a site be on before being nominated?",["暫定リスト","危機遺産リスト","無形文化遺産リスト","世界の記憶"],["Tentative List","List in Danger","Intangible Heritage List","Memory of the World"],0,"各国は暫定リストに記載した遺産から推薦します。","States nominate sites from their Tentative List.",0],
["4","制度・知識","古文書などの記録遺産を保護するユネスコの事業はどれか。","Which UNESCO programme protects documentary heritage?",["世界の記憶","世界遺産","無形文化遺産","ジオパーク"],["Memory of the World","World Heritage","Intangible Heritage","Geoparks"],0,"記録遺産は「世界の記憶」で登録されます。","Documentary heritage is listed under Memory of the World.",0],
["4","制度・知識","「和食」が2013年に登録されたユネスコの制度はどれか。","Under which UNESCO scheme was washoku inscribed in 2013?",["無形文化遺産","世界遺産","世界の記憶","生物圏保存地域"],["Intangible Cultural Heritage","World Heritage","Memory of the World","Biosphere Reserves"],0,"和食は世界遺産ではなく無形文化遺産です。","Washoku is Intangible Heritage, not World Heritage.",1],
["1","制度・知識","文化遺産の保存・修復の研究や研修を行う諮問機関はどれか。","Which advisory body works on conservation and restoration training and research?",["ICCROM","ICOMOS","IUCN","UNHCR"],["ICCROM","ICOMOS","IUCN","UNHCR"],0,"ICCROM（文化財保存修復研究国際センター）です。","ICCROM is the International Centre for the Study of the Preservation and Restoration of Cultural Property.",0],
["2","制度・知識","1978年に世界遺産リストに最初に登録された件数はどれか。","How many sites were inscribed on the list in 1978?",["12件","8件","20件","30件"],["12","8","20","30"],0,"第1回登録は12件でした。","Twelve sites were inscribed first.",0],
["4","日本","日本の世界遺産が最初に登録された年はどれか。","In which year were Japan's first sites inscribed?",["1993年","1972年","2000年","2011年"],["1993","1972","2000","2011"],0,"法隆寺・姫路城・屋久島・白神山地が1993年に登録されました。","Horyu-ji, Himeji, Yakushima, Shirakami-Sanchi in 1993.",0]
];
GEN_Q.forEach((r,i)=>addQ({id:r[0]+"_g"+i,grade:r[0],region:"日本",category:r[1],general:true,
  question:{ja:r[2],en:r[3]},choices:{ja:r[4],en:r[5]},answer:r[6],
  heritageName:{ja:"",en:""},country:{ja:"",en:""},year:"",criteria:"",type:"文化遺産",
  explanation:{ja:r[7],en:r[8]},ng:{ja:"",en:""},tip:{ja:"",en:""},isTrap:!!r[9]}));


/* ---- Japanese sites by prefecture ---- */
const PREF_EN={};"北海道:Hokkaido,青森県:Aomori,岩手県:Iwate,秋田県:Akita,宮城県:Miyagi,福島県:Fukushima,栃木県:Tochigi,群馬県:Gunma,東京都:Tokyo,新潟県:Niigata,石川県:Ishikawa,長野県:Nagano,静岡県:Shizuoka,愛知県:Aichi,京都府:Kyoto,大阪府:Osaka,兵庫県:Hyogo,奈良県:Nara,和歌山県:Wakayama,島根県:Shimane,広島県:Hiroshima,福岡県:Fukuoka,長崎県:Nagasaki,鹿児島県:Kagoshima,沖縄県:Okinawa".split(",").forEach(x=>{const [a,b]=x.split(":");PREF_EN[a]=b;});
[["法隆寺地域の仏教建造物群","Buddhist Monuments in the Horyu-ji Area","奈良県",1993,"文化遺産","4"],
 ["姫路城","Himeji Castle","兵庫県",1993,"文化遺産","4"],
 ["屋久島","Yakushima","鹿児島県",1993,"自然遺産","4"],
 ["原爆ドーム","Hiroshima Peace Memorial (Genbaku Dome)","広島県",1996,"文化遺産","4"],
 ["厳島神社","Itsukushima Shinto Shrine","広島県",1996,"文化遺産","4"],
 ["知床","Shiretoko","北海道",2005,"自然遺産","4"],
 ["日光の社寺","Shrines and Temples of Nikko","栃木県",1999,"文化遺産","3"],
 ["琉球王国のグスク及び関連遺産群","Gusuku Sites and Related Properties of the Kingdom of Ryukyu","沖縄県",2000,"文化遺産","3"],
 ["石見銀山遺跡とその文化的景観","Iwami Ginzan Silver Mine and its Cultural Landscape","島根県",2007,"文化遺産","3"],
 ["小笠原諸島","Ogasawara Islands","東京都",2011,"自然遺産","3"],
 ["平泉","Hiraizumi","岩手県",2011,"文化遺産","3"],
 ["富岡製糸場と絹産業遺産群","Tomioka Silk Mill and Related Sites","群馬県",2014,"文化遺産","3"],
 ["「神宿る島」宗像・沖ノ島と関連遺産群","Sacred Island of Okinoshima and Associated Sites in the Munakata Region","福岡県",2017,"文化遺産","2"],
 ["百舌鳥・古市古墳群","Mozu-Furuichi Kofun Group","大阪府",2019,"文化遺産","2"],
 ["佐渡島の金山","Sado Island Gold Mines","新潟県",2024,"文化遺産","2"]
].forEach(r=>{
  const ds=pickN(Object.keys(PREF_EN).filter(x=>x!==r[2]),3), pc=[r[2],...ds];
  addQ({id:r[5]+"_p"+hash36(r[0]),grade:r[5],region:"日本",category:"所在地",
    question:{ja:`「${r[0]}」が所在する都道府県はどれか。`,en:`In which prefecture is “${r[1]}” located?`},
    choices:{ja:pc,en:pc.map(x=>PREF_EN[x])},answer:0,
    heritageName:{ja:r[0],en:r[1]},country:{ja:"日本",en:"Japan"},year:r[3],criteria:"",type:r[4],
    explanation:{ja:`${r[0]}は${r[2]}にあります（${r[3]}年登録）。`,en:`${r[1]} is in ${PREF_EN[r[2]]} Prefecture (inscribed ${r[3]}).`},
    ng:{ja:"都道府県と遺産名をセットで覚える。",en:"Learn each prefecture with its site."},tip:{ja:"地図で位置を確認しよう。",en:"Check the location on a map."},isTrap:false});
});


/* ---- Advanced questions (Level 1 / Pre-1): "grade|category|question|answer|wrong1|wrong2|wrong3|explanation|trap" ---- */
const HARD_Q=`
1|条約|世界遺産条約の正式名称はどれか。|世界の文化遺産及び自然遺産の保護に関する条約|無形文化遺産の保護に関する条約|武力紛争の際の文化財の保護に関する条約|特に水鳥の生息地として国際的に重要な湿地に関する条約|1972年採択。無形文化遺産条約は2003年、ハーグ条約は1954年、ラムサール条約は1971年です。|0
1|条約|世界遺産委員会の設置を定めているのは世界遺産条約第何条か。|第8条|第11条|第15条|第27条|第8条で委員会、第11条で世界遺産リストと危機遺産リスト、第15条で世界遺産基金を定めます。|0
1|条約|世界遺産基金への締約国の義務的拠出額として正しいものはどれか。|ユネスコ分担金の1%を超えない範囲の一律の割合|ユネスコ分担金の5%|ユネスコ分担金の10%|一律10万ドル|拠出は原則2年ごとに行います。|0
1|条約|新規推薦に対する世界遺産委員会の決議区分として存在しないものはどれか。|登録保留|登録|情報照会|登録延期|決議区分は「登録」「情報照会」「登録延期」「不登録」の4つです。|1
1|条約|世界遺産条約誕生の契機となった、エジプトの神殿群の移設救済事業はどれか。|ヌビア遺跡救済キャンペーン|生物圏保存地域計画|世界の記憶事業|ジオパーク事業|アスワン・ハイ・ダム建設に伴いアブ・シンベル神殿などが救済されました。|0
1|条約|世界遺産条約が採択されたユネスコ総会の開催地はどこか。|パリ|ジュネーヴ|ニューヨーク|ローマ|1972年の第17回ユネスコ総会（パリ）で採択されました。|0
p1|条約|世界遺産条約が発効した年はどれか。|1975年|1972年|1978年|1992年|20か国が受諾した1975年に発効しました。|0
p1|制度|登録基準の区分として正しいものはどれか。|(i)〜(vi)は文化遺産、(vii)〜(x)は自然遺産の基準|(i)〜(iv)は文化遺産、(v)〜(x)は自然遺産の基準|(i)〜(x)はすべて文化遺産の基準|(vii)〜(x)は文化遺産の基準|複合遺産は文化・自然の基準をそれぞれ1つ以上満たします。|0
1|制度|登録基準(iii)の内容として正しいものはどれか。|文化的伝統または文明の存在に関する独特な証拠|建築・技術などの価値観の重要な交流|人類の創造的才能を表す傑作|歴史上の重要な段階を示す建築様式などの優れた例|(i)傑作、(ii)交流、(iii)証拠、(iv)優れた例、(v)伝統的集落、(vi)出来事・思想との関連。|0
1|制度|登録基準(ii)の内容として正しいものはどれか。|建築・技術・芸術などに関する人類の価値の重要な交流を示す|文化的伝統の独特な証拠|歴史上の重要な段階を示す建築物の優れた例|伝統的集落や土地利用の優れた例|(ii)は「価値観の交流」です。|0
p1|制度|登録基準(vi)に関する説明として最も適切なものはどれか。|顕著な普遍的価値をもつ出来事・思想・信仰などと直接関連する|人類の創造的才能を表す傑作|伝統的集落・土地利用の優れた例|生物多様性の保全上重要な自然生息地|(vi)は他の基準と併用されることが望ましいとされています。|0
1|制度|世界遺産登録に必要な「完全性」の説明として最も適切なものはどれか。|価値を伝える要素が損なわれず、そろっていること|創建当初の材料・工法が保たれていること|国宝に指定されていること|複数の国にまたがること|真正性は文化遺産の条件、完全性は文化・自然の両方の条件です。|1
p1|文化的景観|文化的景観の概念が導入された年はどれか。|1992年|1972年|1978年|2003年|1992年に作業指針が改訂され、文化的景観が導入されました。|0
1|文化的景観|文化的景観の概念で最初に登録された遺産はどれか。|トンガリロ国立公園|ウルル=カタ・ジュタ国立公園|バリ州の文化的景観|石見銀山遺跡とその文化的景観|1993年、ニュージーランドのトンガリロ国立公園が最初です。|1
1|複合遺産|ウルル=カタ・ジュタ国立公園が複合遺産となった年はどれか。|1994年|1987年|1992年|2000年|1987年に自然遺産として登録され、1994年に文化的基準が追加されました。|1
p1|日本|「ル・コルビュジエの建築作品」を構成する国の数はどれか。|7か国|3か国|5か国|9か国|フランス・スイス・ベルギー・ドイツ・アルゼンチン・インド・日本の7か国17資産（2016年）。|0
p1|日本|「明治日本の産業革命遺産」の構成資産数と対象県数の組み合わせはどれか。|23資産・8県|17資産・5県|12資産・4県|48資産・10県|2015年登録。九州・山口に加え岩手・静岡も含みます。|0
p1|日本|「古都京都の文化財」の構成資産数はどれか。|17|9|12|23|京都市・宇治市・大津市にまたがる17資産です。|0
p1|日本|「古都奈良の文化財」の構成資産数はどれか。|8|17|9|12|東大寺・興福寺・春日大社・元興寺・薬師寺・唐招提寺・平城宮跡・春日山原始林の8資産。|0
1|日本|「古都奈良の文化財」の構成資産に含まれないものはどれか。|法隆寺|東大寺|興福寺|平城宮跡|法隆寺は「法隆寺地域の仏教建造物群」として別に登録されています。|1
p1|日本|「琉球王国のグスク及び関連遺産群」の構成資産数はどれか。|9|5|12|17|5つのグスクと4つの関連遺産の計9資産です。|0
p1|日本|「長崎と天草地方の潜伏キリシタン関連遺産」の構成資産数はどれか。|12|9|17|8|2018年登録の12資産です。|0
p1|日本|「百舌鳥・古市古墳群」に含まれる古墳の数はどれか。|49基|23基|26基|89基|百舌鳥エリア23基と古市エリア26基の計49基です。|0
p1|日本|「「神宿る島」宗像・沖ノ島と関連遺産群」の構成資産数はどれか。|8|5|12|23|沖ノ島や宗像大社の各宮、新原・奴山古墳群など8資産です。|0
p1|日本|「北海道・北東北の縄文遺跡群」の構成資産数はどれか。|17|9|12|23|2021年登録の17資産です。|0
1|日本|「富士山－信仰の対象と芸術の源泉」の構成資産数はどれか。|25|17|12|8|富士山域・富士五湖・浅間大社・三保松原などの25資産です。|0
1|日本|「日光の社寺」を構成する建造物の棟数はどれか。|103棟|48棟|17棟|9棟|国宝9棟・重要文化財94棟の計103棟です。|0
p1|日本|「富岡製糸場と絹産業遺産群」に含まれない資産はどれか。|碓氷峠鉄道施設|田島弥平旧宅|高山社跡|荒船風穴|構成資産は富岡製糸場・田島弥平旧宅・高山社跡・荒船風穴の4つです。|1
p1|日本|「紀伊山地の霊場と参詣道」の霊場に含まれないものはどれか。|伊勢神宮|熊野三山|高野山|吉野・大峯|三霊場は吉野・大峯、熊野三山、高野山です。伊勢神宮は世界遺産ではありません。|1
p1|日本|「白川郷・五箇山の合掌造り集落」を構成する集落に含まれないものはどれか。|馬籠宿|荻町|相倉|菅沼|荻町（白川郷）、相倉・菅沼（五箇山）の3集落です。|1
1|日本|「平泉」の構成資産に含まれないものはどれか。|瑞巌寺|中尊寺|毛越寺|無量光院跡|構成資産は中尊寺・毛越寺・観自在王院跡・無量光院跡・金鶏山の5つです。|1
1|日本|登録基準(x)のみで登録されている日本の自然遺産はどれか。|奄美大島、徳之島、沖縄島北部及び西表島|屋久島|知床|白神山地|屋久島は(vii)(ix)、知床は(ix)(x)、白神山地は(ix)です。|1
1|日本|「石見銀山遺跡とその文化的景観」に適用された登録基準の組み合わせはどれか。|(ii)(iii)(v)|(i)(iv)|(iii)(vi)|(vii)(ix)|鉱山と周辺の景観が評価されました。|0
p1|1978年|1978年に登録された最初の12件に含まれないものはどれか。|マチュ・ピチュ|ゴレ島|アーヘン大聖堂|イエローストーン国立公園|マチュ・ピチュは1983年の登録です。|1
1|1978年|世界遺産リストの登録番号1番の遺産はどれか。|ガラパゴス諸島|ゴレ島|アーヘン大聖堂|ナハニ国立公園|第1回登録でガラパゴス諸島が登録番号1番です。|0
p1|危機遺産|1992年に登録と同時に危機遺産となり、2004年に解除されたカンボジアの遺産はどれか。|アンコール|プレア・ヴィヒア寺院|サンボー・プレイ・クック|ソーン|アンコールは保存修復の国際協力により解除されました。|0
p1|危機遺産|1991年に危機遺産リストに載り、1998年に解除されたクロアチアの都市はどれか。|ドゥブロヴニク旧市街|スプリト|トロギル|ザダル|紛争による被害で危機遺産となりました。|0
1|危機遺産|（2024年時点で）危機遺産リストに登録されている遺産はどれか。|エルサレムの旧市街とその城壁|アンコール|ドゥブロヴニク旧市街|ケルン大聖堂|エルサレムは1982年から。ケルン大聖堂は2006年に解除されました。|1
1|危機遺産|2001年に大仏が破壊され、2003年に登録と同時に危機遺産となったアフガニスタンの遺産はどれか。|バーミヤン渓谷の文化的景観と古代遺跡群|ジャムのミナレットと考古遺跡|パルミラ遺跡|ハトラ|石窟の仏教遺跡群が評価されました。|0
2|負の遺産|アパルトヘイト時代にマンデラ氏が収監されたことで知られる遺産はどれか。|ロベン島|ゴレ島|ハシマ|アウシュヴィッツ=ビルケナウ|南アフリカにあり1999年に登録されました。|0
2|国境|イグアスの滝を擁する国立公園が所在する国の組み合わせはどれか。|アルゼンチンとブラジル|ブラジルとパラグアイ|チリとアルゼンチン|ブラジルとペルー|アルゼンチン側とブラジル側がそれぞれ登録されています。|0
2|国境|ヴィクトリアの滝（モシ・オ・トゥニャ）が所在する国の組み合わせはどれか。|ザンビアとジンバブエ|タンザニアとケニア|ボツワナとナミビア|南アフリカとモザンビーク|1989年登録の自然遺産です。|0
`.trim().split("\n").forEach((line,i)=>{
  const f=line.split("|"); if(f.length<9) return;
  const c=[f[3],f[4],f[5],f[6]];
  addQ({id:f[0]+"_h"+i+hash36(f[2]),grade:f[0],region:"日本",category:f[1],general:true,hard:true,
    question:{ja:f[2],en:f[2]},choices:{ja:c,en:c},answer:0,
    heritageName:{ja:"",en:""},country:{ja:"",en:""},year:"",criteria:"",type:"文化遺産",
    explanation:{ja:f[7],en:f[7]},ng:{ja:"",en:""},tip:{ja:"",en:""},isTrap:f[8]==="1"});
});

// Extra explicit trap questions
const EXTRA_TRAPS = [
  {
    g:"3", cat:"種別",
    qj:"富士山はどの種別の世界遺産として登録されているか。",
    qe:"Under which category was Fujisan inscribed?",
    cj:["文化遺産","自然遺産","複合遺産","無形文化遺産"],
    ce:["Cultural","Natural","Mixed","Intangible"],
    a:0,
    namej:"富士山－信仰の対象と芸術の源泉", namee:"Fujisan...",
    cj2:"日本", ce2:"Japan", y:2013, crit:"(iii)(vi)", typ:"文化遺産",
    ej:"【超頻出ひっかけ】富士山は自然遺産ではなく文化遺産です。信仰の対象・芸術の源泉として評価。",
    ee:"[Classic trap] Fujisan is cultural, not natural. Valued as sacred place and source of artistic inspiration.",
    tipj:"「自然の富士山」イメージに惑わされないこと。", tipe:"Do not be misled by the image of ‘natural Mt. Fuji’."
  },
  {
    g:"2", cat:"種別",
    qj:"マチュ・ピチュの種別として正しいものはどれか。",
    qe:"What is the correct type of Machu Picchu?",
    cj:["複合遺産","文化遺産","自然遺産","負の遺産"],
    ce:["Mixed","Cultural","Natural","Negative heritage"],
    a:0,
    namej:"マチュ・ピチュ", namee:"Historic Sanctuary of Machu Picchu",
    cj2:"ペルー", ce2:"Peru", y:1983, crit:"(i)(iii)(vii)(ix)", typ:"複合遺産",
    ej:"文化的価値と自然的価値の両方で登録された複合遺産です。",
    ee:"Inscribed as a mixed site for both cultural and natural values.",
    tipj:"複合遺産は数が少ないのでリスト化して覚える。", tipe:"There are few mixed sites — make a list and memorize them."
  },
  {
    g:"1", cat:"構成資産",
    qj:"「軍艦島（端島炭坑）」は次のどの世界遺産の構成資産か。",
    qe:"Hashima Island (Gunkanjima) is a component part of which World Heritage site?",
    cj:["明治日本の産業革命遺産","石見銀山遺跡とその文化的景観","富岡製糸場と絹産業遺産群","佐渡島の金山"],
    ce:["Sites of Japan’s Meiji Industrial Revolution","Iwami Ginzan Silver Mine","Tomioka Silk Mill","Sado Island Gold Mines"],
    a:0,
    namej:"明治日本の産業革命遺産", namee:"Sites of Japan’s Meiji Industrial Revolution",
    cj2:"日本", ce2:"Japan", y:2015, crit:"(ii)(iv)", typ:"文化遺産",
    ej:"軍艦島は単独の世界遺産ではなく、明治日本の産業革命遺産の構成資産の一つです。",
    ee:"Gunkanjima is not a World Heritage site by itself; it is one component of the Meiji Industrial Revolution sites.",
    tipj:"「軍艦島＝世界遺産」と覚えていると落とされる典型的ひっかけ。", tipe:"Classic trap: people think ‘Gunkanjima = World Heritage’ by itself."
  },
  {
    g:"p1", cat:"登録基準",
    qj:"登録基準(vi)のみで登録されている日本の世界遺産はどれか。",
    qe:"Which Japanese World Heritage site is inscribed under criterion (vi) alone?",
    cj:["広島平和記念碑（原爆ドーム）","法隆寺地域の仏教建造物群","厳島神社","富士山"],
    ce:["Hiroshima Peace Memorial (Genbaku Dome)","Buddhist Monuments in the Horyu-ji Area","Itsukushima Shinto Shrine","Fujisan"],
    a:0,
    namej:"広島平和記念碑（原爆ドーム）", namee:"Hiroshima Peace Memorial",
    cj2:"日本", ce2:"Japan", y:1996, crit:"(vi)", typ:"文化遺産",
    ej:"原爆ドームは登録基準(vi)のみで登録された稀有な例です。負の遺産の代表。",
    ee:"The Genbaku Dome is a rare case inscribed under criterion (vi) alone. Archetypal negative heritage.",
    tipj:"(vi)単独＝負の遺産、というイメージを持っておく。", tipe:"Associate ‘(vi) alone’ with negative heritage."
  },
  {
    g:"4", cat:"登録年",
    qj:"日本で最初に世界遺産に登録された自然遺産の組み合わせとして正しいものはどれか。",
    qe:"Which pair were the first natural World Heritage sites inscribed in Japan?",
    cj:["屋久島と白神山地","屋久島と知床","白神山地と小笠原諸島","知床と小笠原諸島"],
    ce:["Yakushima and Shirakami-Sanchi","Yakushima and Shiretoko","Shirakami-Sanchi and Ogasawara","Shiretoko and Ogasawara"],
    a:0,
    namej:"屋久島 / 白神山地", namee:"Yakushima / Shirakami-Sanchi",
    cj2:"日本", ce2:"Japan", y:1993, crit:"(vii)(ix) / (ix)", typ:"自然遺産",
    ej:"1993年に屋久島と白神山地が日本初の自然遺産として同時登録されました。",
    ee:"In 1993 Yakushima and Shirakami-Sanchi were inscribed together as Japan’s first natural sites.",
    tipj:"1993年＝日本の世界遺産元年（文化も自然も）。", tipe:"1993 = Japan’s first World Heritage year (both cultural and natural)."
  }
];

EXTRA_TRAPS.forEach(tr=>{
  addQ({
    id: tr.g + "_x" + hash36(tr.qj),
    grade: tr.g,
    region: regionOf(tr.cj2),
    fixedOrder: false,
    category: tr.cat,
    question: {ja:tr.qj, en:tr.qe},
    choices: {ja:tr.cj, en:tr.ce},
    answer: tr.a,
    heritageName: {ja:tr.namej, en:tr.namee},
    country: {ja:tr.cj2, en:tr.ce2},
    year: tr.y,
    criteria: tr.crit,
    type: tr.typ,
    explanation: {ja:tr.ej, en:tr.ee},
    ng: {ja:"ひっかけ問題です。よくある誤解を突いています。", en:"This is a trap question targeting common misconceptions."},
    tip: {ja:tr.tipj, en:tr.tipe},
    isTrap: true
  });
});

/* Shuffle choices per attempt (same permutation for every language) */
function prepQ(q){
  if(q.fixedOrder) return q;
  if(!q._c0){ q._c0={ja:(q.choices.ja||[]).slice(), en:(q.choices.en||[]).slice()}; q._a0=q.answer; }
  const n=q._c0.ja.length;
  const perm=shuffle([...Array(n).keys()]);
  if(q.cc){ if(!q._cc0) q._cc0=q.cc.slice(); q.cc=perm.map(i=>q._cc0[i]); }
  q.choices={ja:perm.map(i=>q._c0.ja[i]), en:perm.map(i=>(q._c0.en[i]!==undefined?q._c0.en[i]:q._c0.ja[i]))};
  q.answer=perm.indexOf(q._a0);
  return q;
}
function prepList(list){ list.forEach(prepQ); return list; }
