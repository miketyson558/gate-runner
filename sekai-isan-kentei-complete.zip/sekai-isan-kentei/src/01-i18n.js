/* =====================================================================
   世界遺産検定 対策クイズ  v2  —  Multi-language · Colorful · Trap questions
   Single-file self-contained HTML/CSS/JS
   ===================================================================== */

/* ---------- i18n Core ---------- */
const LANGS = {
  ja: {
    code:"ja", name:"日本語",
    title:"世界遺産検定 対策",
    all:"すべて", grade:"級", grades:{4:"4級",3:"3級",2:"2級",p1:"準1級",1:"1級"},
    todayStudy:"今日の学習", accuracy:"正答率", goal:"今日の目標", time:"学習時間",
    solved:"解答済み", qunit:"問", min:"分",
    modes:{random:"ランダム",fresh:"初挑戦",wrong:"間違い",bm:"ブックマーク"},
    field:"学習する分野", change:"変更",
    startRandom:"ランダムで始める", startSmart:"スマート復習（苦手を優先）",
    menu:{mock:"模擬試験", flash:"暗記カード", browse:"遺産を探す", report:"学習レポート", guide:"試験ガイド"},
    mockDesc:"級に合わせた問題数・制限時間で挑戦",
    flashDesc:"遺産名・国・登録年・基準をめくって復習",
    browseDesc:"登録遺産を一覧・検索",
    reportDesc:"正答率・苦手傾向を確認",
    guideDesc:"級ごとの出題範囲と攻略ポイント",
    next:"次の問題へ", finish:"結果を見る", share:"共有", bookmark:"ブックマーク",
    correct:"正解！", wrong:"不正解…",
    detail:"詳しい解説", heritage:"遺産名", country:"所在国", year:"登録年",
    type:"種別", criteria:"登録基準", history:"歴史・特徴", trapNote:"ひっかけポイント",
    tip:"覚え方のコツ", ngReason:"他の選択肢が誤りの理由",
    settings:"設定", lang:"表示言語", bgm:"BGM", se:"効果音", volume:"音量", voice:"音声出題", voiceAuto:"問題を自動で読み上げ", speak:"読み上げ", stopSpeak:"停止", speakAnswer:"話して答える", listening:"聞いています…", micDenied:"マイクの許可が必要です", noSpeechSupport:"このブラウザは音声認識に対応していません",
    goalSet:"1日の目標問題数", save:"保存", close:"閉じる",
    trapMode:"ひっかけ注意モード", trapBadge:"ひっかけ",
    noData:"データがありません", continue:"続きから",
    shareResult:"学習結果を共有", shareQ:"この問題を共有",
    copied:"コピーしました", shareFail:"共有できませんでした",
    resultTitle:"学習結果", score:"得点", rate:"正答率",
    smart:"スマート復習", home:"ホーム",
    fields:{all:"すべて",jp:"日本の遺産",world:"世界の遺産",cultural:"文化遺産",natural:"自然・複合遺産"},
    typeNames:{文化遺産:"文化遺産",自然遺産:"自然遺産",複合遺産:"複合遺産"},
    criteriaLabel:"登録基準の意味",
    search:"検索", filter:"絞り込み",
    mockStart:"模擬試験を始める", mockTime:"制限時間", mockQ:"問題数",
    flashFlip:"タップで裏面", prev:"前へ", nextCard:"次へ",
    reportGrade:"級別正答率", reportCat:"問題種類別", reportRegion:"地域別",
    topWrong:"間違いが多い遺産 TOP5",
    guideTitle:"試験ガイド",
    autoLang:"端末言語を優先", again:"もう一度",
    review:"振り返り", passed:"合格ライン（70%）クリア！", failed:"合格ライン（70%）まであと少し", timeUp:"時間切れ", mockInfo:"問・制限時間", searchPh:"遺産名・国で検索", items:"件", unans:"未回答"
  },
  en: {
    code:"en", name:"English",
    title:"World Heritage Quiz",
    all:"All", grade:"Level", grades:{4:"Level 4",3:"Level 3",2:"Level 2",p1:"Pre-1",1:"Level 1"},
    todayStudy:"Today", accuracy:"Accuracy", goal:"Daily goal", time:"Study time",
    solved:"Solved", qunit:"Q", min:"min",
    modes:{random:"Random",fresh:"New",wrong:"Missed",bm:"Bookmarks"},
    field:"Category", change:"Change",
    startRandom:"Start Random", startSmart:"Smart Review (focus on weak)",
    menu:{mock:"Mock Exam", flash:"Flashcards", browse:"Browse Sites", report:"Report", guide:"Exam Guide"},
    mockDesc:"Timed exam by level",
    flashDesc:"Flip name / country / year / criteria",
    browseDesc:"Search & list heritage sites",
    reportDesc:"Accuracy & weak areas",
    guideDesc:"Syllabus & tips by level",
    next:"Next Question", finish:"See Results", share:"Share", bookmark:"Bookmark",
    correct:"Correct!", wrong:"Incorrect…",
    detail:"Detailed Explanation", heritage:"Site", country:"Country", year:"Inscribed",
    type:"Type", criteria:"Criteria", history:"History & Features", trapNote:"Trap Alert",
    tip:"Memory Tip", ngReason:"Why other choices are wrong",
    settings:"Settings", lang:"Language", bgm:"BGM", se:"Sound FX", volume:"Volume", voice:"Voice quiz", voiceAuto:"Auto-read questions", speak:"Speak", stopSpeak:"Stop", speakAnswer:"Speak to answer", listening:"Listening…", micDenied:"Microphone permission required", noSpeechSupport:"Speech recognition is not supported in this browser",
    goalSet:"Daily goal (questions)", save:"Save", close:"Close",
    trapMode:"Trap-alert mode", trapBadge:"TRAP",
    noData:"No data", continue:"Continue",
    shareResult:"Share results", shareQ:"Share this question",
    copied:"Copied!", shareFail:"Share failed",
    resultTitle:"Results", score:"Score", rate:"Accuracy",
    smart:"Smart Review", home:"Home",
    fields:{all:"All",jp:"Japan",world:"World",cultural:"Cultural",natural:"Natural / Mixed"},
    typeNames:{文化遺産:"Cultural",自然遺産:"Natural",複合遺産:"Mixed"},
    criteriaLabel:"Meaning of Criteria",
    search:"Search", filter:"Filter",
    mockStart:"Start Mock Exam", mockTime:"Time limit", mockQ:"Questions",
    flashFlip:"Tap to flip", prev:"Prev", nextCard:"Next",
    reportGrade:"By Level", reportCat:"By Category", reportRegion:"By Region",
    topWrong:"Most Missed Sites TOP5",
    guideTitle:"Exam Guide",
    autoLang:"Prefer device language", again:"Try again",
    review:"Review", passed:"Passed (70% line)!", failed:"Just short of the 70% line", timeUp:"Time up", mockInfo:"Q · time limit", searchPh:"Search site or country", items:"items", unans:"Unanswered"
  },
  // Extensible stubs (fallback to en)
  fr: {code:"fr", name:"Français", title:"Quiz du Patrimoine Mondial"},
  es: {code:"es", name:"Español", title:"Quiz del Patrimonio Mundial"},
  zh: {code:"zh", name:"中文", title:"世界遗产测验"},
  ko: {code:"ko", name:"한국어", title:"세계유산 퀴즈"},

  pt: {code:"pt", name:"Português", title:"Quiz do Patrimônio Mundial"},
  de: {code:"de", name:"Deutsch", title:"Welterbe-Quiz"},
  it: {code:"it", name:"Italiano", title:"Quiz del Patrimonio Mondiale"},
  ar: {code:"ar", name:"العربية", title:"اختبار التراث العالمي"},
  hi: {code:"hi", name:"हिन्दी", title:"विश्व धरोहर क्विज़"},
  ru: {code:"ru", name:"Русский", title:"Викторина Всемирного наследия"},
  th: {code:"th", name:"ไทย", title:"แบบทดสอบมรดกโลก"},
  id: {code:"id", name:"Bahasa Indonesia", title:"Kuis Warisan Dunia"},
  tr: {code:"tr", name:"Türkçe", title:"Dünya Mirası Quiz"}
};

// Merge fallbacks
Object.keys(LANGS).forEach(k=>{
  if(k!=="ja" && k!=="en"){
    LANGS[k] = Object.assign({}, LANGS.en, LANGS[k]);
  }
});


/* ---------- UI translations (core strings) ---------- */
const UIX_KEYS=["todayStudy","accuracy","goal","solved","qunit","min","m_random","m_fresh","m_wrong","m_bm","startRandom","startSmart","mock","flash","browse","report","guide","next","finish","share","bookmark","correct","wrong","detail","heritage","country","year","type","criteria","settings","lang","close","home","resultTitle","again","review","searchPh","mockStart","trapBadge","all","gw","cul","nat","mix","flashFlip","prev","nextCard","noData","history","tip","change","field"];
const UIX={
fr:"Aujourd'hui|Précision|Objectif|Résolues|Q|min|Aléatoire|Nouvelles|Ratées|Favoris|Démarrer (aléatoire)|Révision intelligente|Examen blanc|Cartes mémo|Explorer les sites|Bilan|Guide d'examen|Question suivante|Voir les résultats|Partager|Favori|Correct !|Incorrect…|Explication détaillée|Site|Pays|Inscription|Type|Critères|Paramètres|Langue|Fermer|Accueil|Résultats|Rejouer|Révision|Rechercher un site ou un pays|Lancer l'examen blanc|PIÈGE|Tous|Niveau|Culturel|Naturel|Mixte|Touchez pour retourner|Préc.|Suiv.|Aucune donnée|Histoire et caractéristiques|Astuce|Modifier|Catégorie",
es:"Hoy|Precisión|Meta|Resueltas|P|min|Aleatorio|Nuevas|Falladas|Favoritas|Empezar (aleatorio)|Repaso inteligente|Examen simulado|Tarjetas|Explorar sitios|Informe|Guía del examen|Siguiente pregunta|Ver resultados|Compartir|Favorito|¡Correcto!|Incorrecto…|Explicación detallada|Sitio|País|Inscripción|Tipo|Criterios|Ajustes|Idioma|Cerrar|Inicio|Resultados|Repetir|Repaso|Buscar sitio o país|Iniciar examen simulado|TRAMPA|Todos|Nivel|Cultural|Natural|Mixto|Toca para girar|Ant.|Sig.|Sin datos|Historia y características|Consejo|Cambiar|Categoría",
zh:"今日|正确率|目标|已答|题|分钟|随机|未做|错题|收藏|随机开始|智能复习|模拟考试|记忆卡|浏览遗产|学习报告|考试指南|下一题|查看结果|分享|收藏|正确！|错误…|详细解说|遗产|所在国|登录年|类别|登录标准|设置|语言|关闭|首页|学习结果|再来一次|回顾|按遗产名或国家搜索|开始模拟考试|陷阱|全部|级|文化遗产|自然遗产|复合遗产|点击翻面|上一张|下一张|暂无数据|历史与特点|记忆技巧|更改|领域",
ko:"오늘|정답률|목표|푼 문제|문제|분|랜덤|새 문제|오답|북마크|랜덤으로 시작|스마트 복습|모의시험|암기 카드|유산 찾기|학습 리포트|시험 가이드|다음 문제|결과 보기|공유|북마크|정답!|오답…|상세 해설|유산|소재국|등재 연도|유형|등재 기준|설정|언어|닫기|홈|학습 결과|다시 하기|복습|유산명·국가로 검색|모의시험 시작|함정|전체|급|문화유산|자연유산|복합유산|탭하여 뒤집기|이전|다음|데이터 없음|역사와 특징|암기 팁|변경|분야",
pt:"Hoje|Acertos|Meta|Resolvidas|Q|min|Aleatório|Novas|Erradas|Favoritas|Começar (aleatório)|Revisão inteligente|Simulado|Cartões|Explorar sítios|Relatório|Guia do exame|Próxima pergunta|Ver resultados|Compartilhar|Favorito|Correto!|Incorreto…|Explicação detalhada|Sítio|País|Inscrição|Tipo|Critérios|Configurações|Idioma|Fechar|Início|Resultados|Repetir|Revisão|Buscar sítio ou país|Iniciar simulado|PEGADINHA|Todos|Nível|Cultural|Natural|Misto|Toque para virar|Ant.|Próx.|Sem dados|História e características|Dica|Alterar|Categoria",
de:"Heute|Genauigkeit|Ziel|Gelöst|F|Min.|Zufall|Neu|Falsch|Lesezeichen|Zufällig starten|Intelligente Wiederholung|Probeprüfung|Lernkarten|Stätten durchsuchen|Bericht|Prüfungsleitfaden|Nächste Frage|Ergebnis ansehen|Teilen|Lesezeichen|Richtig!|Falsch…|Ausführliche Erklärung|Stätte|Land|Eintragung|Typ|Kriterien|Einstellungen|Sprache|Schließen|Start|Ergebnis|Nochmal|Rückblick|Stätte oder Land suchen|Probeprüfung starten|FALLE|Alle|Stufe|Kultur|Natur|Gemischt|Zum Wenden tippen|Zurück|Weiter|Keine Daten|Geschichte und Merkmale|Merktipp|Ändern|Bereich",
it:"Oggi|Precisione|Obiettivo|Risolte|D|min|Casuale|Nuove|Sbagliate|Preferite|Inizia (casuale)|Ripasso intelligente|Simulazione|Schede|Esplora i siti|Report|Guida all'esame|Prossima domanda|Vedi risultati|Condividi|Preferito|Corretto!|Sbagliato…|Spiegazione dettagliata|Sito|Paese|Iscrizione|Tipo|Criteri|Impostazioni|Lingua|Chiudi|Home|Risultati|Riprova|Rivedi|Cerca sito o paese|Avvia simulazione|TRABOCCHETTO|Tutti|Livello|Culturale|Naturale|Misto|Tocca per girare|Prec.|Succ.|Nessun dato|Storia e caratteristiche|Consiglio|Cambia|Categoria"
};
Object.keys(UIX).forEach(l=>{
  const v=UIX[l].split("|"), o={}; UIX_KEYS.forEach((k,i)=>o[k]=v[i]);
  const gf=n=>l==="zh"?n+"级":l==="ko"?n+"급":o.gw+" "+n;
  const p1=l==="zh"?"准1级":l==="ko"?"준1급":"Pre-1";
  const L=LANGS[l];
  Object.assign(L,{todayStudy:o.todayStudy,accuracy:o.accuracy,rate:o.accuracy,goal:o.goal,solved:o.solved,qunit:o.qunit,min:o.min,
    startRandom:o.startRandom,startSmart:o.startSmart,next:o.next,finish:o.finish,share:o.share,bookmark:o.bookmark,correct:o.correct,wrong:o.wrong,
    detail:o.detail,heritage:o.heritage,country:o.country,year:o.year,type:o.type,criteria:o.criteria,settings:o.settings,lang:o.lang,close:o.close,
    home:o.home,resultTitle:o.resultTitle,again:o.again,review:o.review,searchPh:o.searchPh,mockStart:o.mockStart,trapBadge:o.trapBadge,all:o.all,
    flashFlip:o.flashFlip,prev:o.prev,nextCard:o.nextCard,noData:o.noData,history:o.history,tip:o.tip,change:o.change,field:o.field,smart:o.startSmart,
    reportGrade:o.accuracy+" / "+o.gw,
    modes:{random:o.m_random,fresh:o.m_fresh,wrong:o.m_wrong,bm:o.m_bm},
    menu:{mock:o.mock,flash:o.flash,browse:o.browse,report:o.report,guide:o.guide},
    grades:{4:gf(4),3:gf(3),2:gf(2),p1:p1,1:gf(1)},
    typeNames:{文化遺産:o.cul,自然遺産:o.nat,複合遺産:o.mix},
    fields:Object.assign({},LANGS.en.fields,{all:o.all,cultural:o.cul,natural:o.nat+" / "+o.mix})});
});
const CATEN={"該当遺産":"Identify site","登録年":"Year","種別":"Type","所在国":"Country","登録基準":"Criteria","構成資産":"Components","所在遺産":"Sites by country","種別選択":"Sites by type","登録順":"Inscription order","年→遺産":"Sites by year","所在地":"Prefecture","条約":"Convention","制度":"Criteria & rules","文化的景観":"Cultural landscapes","複合遺産":"Mixed sites","日本":"Japan","1978年":"1978 sites","危機遺産":"Danger list","負の遺産":"Negative heritage","国境":"Transboundary","自作":"My questions","制度・知識":"Convention & facts"};
const REGEN={"日本":"Japan","アジア":"Asia","中東":"Middle East","ヨーロッパ":"Europe","アフリカ":"Africa","南北アメリカ":"Americas","オセアニア":"Oceania","その他":"Other"};
function catName(c){ return curLang==="ja"?c:(CATEN[c]||c); }
function regName(r){ return curLang==="ja"?r:(REGEN[r]||r); }
const ISO={日本:"JP",中国:"CN",インド:"IN",カンボジア:"KH",インドネシア:"ID",ベトナム:"VN",ラオス:"LA",タイ:"TH",ミャンマー:"MM",ヨルダン:"JO",トルコ:"TR",イラン:"IR",フランス:"FR",イギリス:"GB",チェコ:"CZ",イタリア:"IT",ギリシャ:"GR",スペイン:"ES",ポーランド:"PL",ヴァチカン:"VA",オーストリア:"AT",ハンガリー:"HU",ポルトガル:"PT",ジンバブエ:"ZW",タンザニア:"TZ",エジプト:"EG",南アフリカ:"ZA",セネガル:"SN",マリ:"ML",アメリカ合衆国:"US",ペルー:"PE",エクアドル:"EC",チリ:"CL",アルゼンチン:"AR",メキシコ:"MX",ブラジル:"BR",グアテマラ:"GT",ホンジュラス:"HN",オーストラリア:"AU"};
const CEN={};
function cnmJ(ja){
  if(curLang==="ja") return ja;
  if(curLang!=="en" && curLang in UIX || ["ar","hi","ru","th","id","tr"].includes(curLang)){
    try{
      const parts=ja==="ザンビア・ジンバブエ"?["ZM","ZW"]:(ISO[ja]?[ISO[ja]]:null);
      if(parts){ const dn=new Intl.DisplayNames([curLang],{type:"region"}); return parts.map(c=>dn.of(c)).join(" · "); }
    }catch(e){}
  }
  return CEN[ja]||ja;
}
function cnm(o){ if(!o) return ""; if(curLang==="ja"||curLang==="en") return tt(o); return cnmJ(o.ja); }
function choicesOf(q){
  const L=curLang;
  if(L!=="ja"&&L!=="en"){
    if(q.category==="種別") return ["文化遺産","自然遺産","複合遺産"].map(x=>t("typeNames."+x));
    if(q.cc) return q.cc.map(cnmJ);
  }
  return tt(q.choices)||[];
}

let curLang = "ja";
function t(key){
  const L = LANGS[curLang] || LANGS.en;
  const keys = key.split(".");
  let v = L;
  for(const k of keys){ v = v?.[k]; if(v===undefined) break; }
  if(v===undefined){
    // fallback en → ja
    v = LANGS.en; for(const k of keys){ v = v?.[k]; if(v===undefined) break; }
    if(v===undefined){ v = LANGS.ja; for(const k of keys){ v = v?.[k]; } }
  }
  return v !== undefined ? v : key;
}
function tt(obj){ // pick multilingual field — never return empty if any lang exists
  if(obj == null) return "";
  if(typeof obj === "string") return obj;
  if(typeof obj !== "object") return String(obj);
  return obj[curLang] || obj.en || obj.ja || obj.fr || obj.pt || Object.values(obj).find(v => typeof v === "string" && v) || "";
}

/* ---------- Criteria meanings (bilingual) ---------- */
const CRM = {
  i:  {ja:"人類の創造的才能を表す傑作", en:"Masterpiece of human creative genius"},
  ii: {ja:"建築・技術などに関して価値観の交流を示す", en:"Important interchange of human values"},
  iii:{ja:"文化的伝統や文明の存在を伝える証拠", en:"Unique or exceptional testimony to a cultural tradition"},
  iv: {ja:"歴史上の重要な段階を示す建築・景観の優れた例", en:"Outstanding example of a type of building or landscape"},
  v:  {ja:"伝統的な集落や土地利用の優れた例", en:"Outstanding example of traditional human settlement"},
  vi: {ja:"顕著な普遍的価値をもつ出来事・思想・信仰などと関連", en:"Directly associated with events or living traditions of outstanding universal significance"},
  vii:{ja:"類いまれな自然現象や自然美", en:"Superlative natural phenomena or areas of exceptional natural beauty"},
  viii:{ja:"地球の歴史や地形形成の過程を示す顕著な例", en:"Outstanding examples of major stages of Earth's history"},
  ix: {ja:"生態系や生物の進化の過程を示す顕著な例", en:"Outstanding examples of ecological and biological processes"},
  x:  {ja:"生物多様性の保全上、重要な自然の生息地", en:"Most important natural habitats for biodiversity"}
};
