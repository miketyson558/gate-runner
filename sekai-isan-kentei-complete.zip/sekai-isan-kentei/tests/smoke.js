// Smoke test: node tests/smoke.js  (after `node build.js`)
const fs=require("fs"),path=require("path");
const html=fs.readFileSync(path.join(__dirname,"..","dist","sekai-isan-kentei.html"),"utf8");
const js=html.slice(html.indexOf("<script>")+8,html.lastIndexOf("</script>"));
global.appEl={innerHTML:""}; const store={};
global.window=global;
global.document={documentElement:{},hidden:false,querySelector:()=>appEl,getElementById:()=>null,addEventListener(){},removeEventListener(){}};
global.navigator={language:"ja-JP"};
global.localStorage={getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=v};
global.speechSynthesis={cancel(){},speak(){}}; global.SpeechSynthesisUtterance=function(){};
global.setInterval=()=>0; global.setTimeout=()=>0;
(0,eval)(js+";globalThis.T={Q,HL,st,DB,render,startQuiz,pick,advance,startMock,pool,shuffle,choicesOf,parseCustom,initLang,get html(){return appEl.innerHTML}};");
let fail=0; const ok=(c,m)=>{console.log((c?"PASS ":"FAIL ")+m); if(!c) fail++;};
ok(T.Q.length>2000,"questions: "+T.Q.length);
T.Q.forEach(q=>{ if(!q._c0 && !q.fixedOrder) {} });
let bad=0; T.Q.forEach(q=>{ for(const l of ["ja","en"]){const c=q.choices[l]; if(new Set(c).size!==c.length) bad++;} if(!(q.answer>=0&&q.answer<q.choices.ja.length)) bad++; });
ok(bad===0,"no duplicate choices / valid answers");
ok(new Set(T.Q.map(q=>q.id)).size===T.Q.length,"unique question ids");
for(const lang of ["ja","en","fr","es","zh","ko","pt","de","it","ar","hi"]){
  T.DB.set.lang=lang; T.initLang();
  for(const sc of ["home","browse","report","flash","mock","guide","import"]){ T.st.screen=sc; T.st.quiz=null; T.st.fl=null; T.render(); if(/undefined|NaN/.test(T.html)){ok(false,lang+" "+sc);} }
  T.startQuiz(T.shuffle(T.Q).slice(0,40)); T.render(); ok(!/undefined|NaN/.test(T.html),"quiz render "+lang);
}
T.DB.set.lang="ja"; T.initLang();
for(const g of ["4","3","2","p1","1","all"]){ T.DB.set.grade=g; ok(T.pool().length>0,"level "+g+": "+T.pool().length+" questions"); }
T.DB.set.grade="all"; T.startQuiz(); for(let i=0;i<10;i++){ T.pick(T.st.quiz.list[T.st.quiz.i].answer); T.advance(); }
ok(T.st.screen==="result"&&/10 \/ 10/.test(T.html),"full quiz run");
T.startMock(); ok(!!T.st.quiz.deadline,"mock exam timer");
const r=T.parseCustom("3級|日本|テスト問題|A|B|C|D|2|解説"); ok(r.ok===1,"custom import");
console.log(fail?"\n"+fail+" FAILED":"\nALL PASSED"); process.exit(fail?1:0);
