# ぬりえスマイル 最終完成版

## 内容
- 20カテゴリー × 30作品 = **600種類**のオリジナルSVG線画データ
- スマホ/Android/iPhone/PC対応のレスポンシブUI
- 指ドラッグ着色、タップ操作、バケツ、消しゴム、はみ出し防止
- 写真から線画へ変換する既存機能を維持
- Web Audio APIによるBGM/効果音
- Canvasの高解像度座標補正、マルチタッチ対策、overscroll対策
- SVG画像は小容量のLRUキャッシュで保持し、600作品を一括ラスタライズしない構成

## フォルダ構成
```
index.html
style.css
app.js
data/
  cat01.js ... cat20.js
README.md
```

## iPhone/Androidで試す
GitHub PagesなどのHTTPSサーバーにフォルダごとアップロードし、`index.html`を開いてください。
ローカルのHTML直開きでも表示できますが、写真変換・一部ブラウザ機能はHTTPS配信の方が安定します。

## GitHub Pagesへのアップロード
1. GitHubの対象リポジトリを開く
2. `Add file` → `Upload files`
3. このZIPを解凍した**中身**をアップロード
4. `Commit changes`
5. Settings → Pages → Deploy from a branch → `main` / `/ (root)` → Save
6. 表示されたPages URLをSafari/Chromeで開く

## 操作
- カテゴリー → 作品を選択 → 指でドラッグして着色
- バケツ：閉じた領域をタップ
- 消しゴム：塗った部分を消す
- はみ出し防止：線画の外へ塗りが出るのを抑制
- サウンド：BGM/効果音のオン・オフと音量を調整

## 600作品について
各`data/catXX.js`に30作品を格納しています。すべて外部画像を参照せず、ブラウザ内で読み込めるSVG線画データです。
